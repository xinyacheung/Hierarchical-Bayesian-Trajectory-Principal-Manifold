# Hierarchical Bayesian TPM (HB-TPM)

## 1. What is false in the original claim

Finite unordered points do not identify an unrestricted trajectory. For any finite sample set on a smooth curve, one can construct another smooth curve that agrees in neighborhoods of every observed point but takes an arbitrarily different path between or outside those neighborhoods. Therefore no estimator can uniformly recover an arbitrary `C2` curve from `K` sparse, unordered points without extra information.

The finite-shot lemma in `Trajectory_new.pdf` assumes that the recovered ordering already equals the true ordering. The tube theorem assumes a uniform curve error `epsilon_P` is already small. These are useful conditional statements, but they do not prove that the proposed algorithm obtains either condition. In the existing implementation, “ordering” is only sorting by PC1 and the curve is a high-degree Bezier interpolant. This is not a statistically identified principal-curve estimator at K=3 or K=5.

## 2. Identifiable replacement

The model places the learnable structural information in source trajectories:

`gamma_j(t) = Phi(t) W_j`, with `W_j ~ N(W_0, Lambda)`.

Source tasks are densely observed and ordered (time, pseudotime, video frame, dose, or another progression coordinate). A generic smooth basis `Phi` is fixed independently of the simulator; source tasks estimate population mean `W_0`, task variability `Lambda`, and normal-noise scale. A target task supplies only unordered shots

`x_i = Phi(t_i) W_* + epsilon_i`, where each `t_i` is latent.

HB-TPM alternates between nearest-trajectory index assignment and a MAP coefficient update, then samples from the fitted curve with source-calibrated normal noise. The target curve is therefore an adaptation of a learned trajectory family, not a curve invented from K points.

## 3. Bayes-risk advantage

Condition on correctly assigned target indices and let `F` be the K-by-p design matrix with rows `Phi(t_i)`. For one output coordinate, the posterior covariance is

`Sigma_post = (Lambda^-1 + sigma^-2 F^T F)^-1`.

For the target-only estimator, the prior precision is zero, so its covariance is `(sigma^-2 F^T F)^-1` when this inverse exists and is unbounded in unidentified directions when K<p. Since

`Lambda^-1 + sigma^-2 F^T F >= sigma^-2 F^T F`

in positive-semidefinite order, posterior shrinkage weakly lowers integrated Bayes curve risk. The improvement is strict whenever the source prior has finite precision in a direction not fully identified by the target shots. This is the underdetermined or weakly determined regime in the experiment (ten Bernstein coefficients, latent indices, and K in {3,5,10}).

The bound that should replace the original unconditional recovery story is a decomposition:

`curve risk <= source-prior estimation + posterior coefficient risk + index-assignment error + model-family mismatch`.

Normal-bundle sampling only controls a fifth term, the sampling radius. It cannot repair a wrong trajectory estimate.

## 4. Trust gate

HB-TPM should be used only when source validation supports all of the following:

1. target and source trajectories share the fitted basis family;
2. held-out source tasks obtain low projection error under sparse adaptation;
3. projection indices are stable under shot bootstrap;
4. posterior predictive support error is better than Gaussian/VAE validation baselines.

If the gate fails, use the validated baseline. A Gaussian oracle is the important negative control: when the data are actually Gaussian rather than trajectory-supported, Gaussian estimation should win.

## 5. What the advantage is - and is not

The advantage does not come from drawing points along a curve, from a smoothness penalty, or from adding more synthetic points. It comes from transferable structural information that reduces the number of target-specific degrees of freedom. The curve representation makes that information explicit and lets uncertainty be allocated along normal directions. A sufficiently well-specified conditional/meta generative model with the same trajectory supervision could match this advantage; HB-TPM is preferable in the very-low-K regime because its low-dimensional posterior is identifiable and auditable.
