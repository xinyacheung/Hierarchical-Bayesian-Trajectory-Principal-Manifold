from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from core import (
    NumpyVAE,
    TrajectoryOracle,
    curve_error,
    energy_distance,
    fit_hb_tpm,
    gaussian_sample,
    learn_hierarchical_prior,
    naive_tpm_curve,
    sample_curve_grid,
    sample_hb_tpm,
    sliced_wasserstein,
    smote_sample,
    support_metrics,
    trajectory_basis,
)


ROOT = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Oracle trajectory recovery benchmark for HB-TPM.")
    parser.add_argument("--repeats", type=int, default=30)
    parser.add_argument("--k-values", type=int, nargs="+", default=[3, 5, 10])
    parser.add_argument("--n-source", type=int, default=48)
    parser.add_argument("--source-points", type=int, default=96)
    parser.add_argument("--n-eval", type=int, default=192)
    parser.add_argument("--seed", type=int, default=260822)
    parser.add_argument("--out", type=Path, default=ROOT / "results" / "benchmark.json")
    return parser.parse_args()


def summarize(rows: list[dict]) -> list[dict]:
    out: list[dict] = []
    metrics = ["swd", "energy", "support_precision", "support_coverage", "curve_error"]
    keys = sorted({(int(r["k"]), str(r["method"])) for r in rows})
    for k, method in keys:
        group = [r for r in rows if int(r["k"]) == k and str(r["method"]) == method]
        item = {"k": k, "method": method, "n": len(group)}
        for metric in metrics:
            vals = np.array([float(r[metric]) for r in group if r[metric] is not None])
            item[f"{metric}_mean"] = float(vals.mean()) if len(vals) else None
            item[f"{metric}_se"] = float(vals.std(ddof=1) / np.sqrt(len(vals))) if len(vals) > 1 else 0.0
        out.append(item)
    return out


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    oracle = TrajectoryOracle()
    source = [oracle.draw_task(rng, args.source_points, ordered=True) for _ in range(args.n_source)]
    prior = learn_hierarchical_prior(source)
    source_x = np.vstack([task.x for task in source])
    mean = source_x.mean(axis=0)
    scale = np.maximum(source_x.std(axis=0), 0.08)
    source_z = (source_x - mean) / scale

    source_vae = NumpyVAE(source_z.shape[1], hidden_dim=28, latent_dim=2, seed=args.seed + 1)
    source_vae.fit(source_z, steps=2400, batch_size=128, lr=0.003, beta=0.035, seed=args.seed + 2)
    source_anchor = {key: value.copy() for key, value in source_vae.params.items()}

    rows: list[dict] = []
    example: dict | None = None
    grid = np.linspace(0.0, 1.0, 401)
    for repeat in range(args.repeats):
        target = oracle.draw_task(rng, max(args.k_values), ordered=False)
        true_curve = target.curve(grid)
        truth, _ = oracle.resample(target, rng, args.n_eval)
        for k in args.k_values:
            shot_x = target.x[:k].copy()
            method_outputs: dict[str, tuple[np.ndarray, np.ndarray | None]] = {}

            method_outputs["Gaussian"] = (gaussian_sample(shot_x, args.n_eval, rng), None)
            method_outputs["SMOTE"] = (smote_sample(shot_x, args.n_eval, rng), None)
            naive_curve = naive_tpm_curve(shot_x)
            method_outputs["Naive TPM"] = (
                sample_curve_grid(naive_curve, args.n_eval, prior.noise_scale, rng),
                naive_curve,
            )

            target_vae = NumpyVAE(shot_x.shape[1], hidden_dim=28, latent_dim=2, seed=args.seed + repeat * 101 + k)
            target_vae.fit(
                (shot_x - mean) / scale,
                steps=700,
                batch_size=max(k, 8),
                lr=0.004,
                beta=0.035,
                seed=args.seed + repeat * 131 + k,
            )
            method_outputs["Target-only VAE"] = (target_vae.sample(args.n_eval, rng) * scale + mean, None)

            adapted_vae = source_vae.copy()
            adapted_vae.fit(
                (shot_x - mean) / scale,
                steps=180,
                batch_size=max(k, 8),
                lr=0.0015,
                beta=0.035,
                seed=args.seed + repeat * 151 + k,
                anchor=source_anchor,
                anchor_strength=0.025,
            )
            method_outputs["Source-adapted VAE"] = (adapted_vae.sample(args.n_eval, rng) * scale + mean, None)

            w_hb, _ = fit_hb_tpm(shot_x, prior, prior_multiplier=1.0)
            hb_curve = trajectory_basis(grid) @ w_hb
            method_outputs["HB-TPM"] = (
                sample_hb_tpm(w_hb, args.n_eval, prior.noise_scale, rng),
                hb_curve,
            )

            weak_prior = type(prior)(prior.mean, prior.variance, prior.noise_scale)
            w_weak, _ = fit_hb_tpm(shot_x, weak_prior, prior_multiplier=250.0)
            weak_curve = trajectory_basis(grid) @ w_weak
            method_outputs["HB-TPM no shrinkage"] = (
                sample_hb_tpm(w_weak, args.n_eval, prior.noise_scale, rng),
                weak_curve,
            )
            method_outputs["HB-TPM isotropic"] = (
                sample_hb_tpm(w_hb, args.n_eval, prior.noise_scale, rng, isotropic=True),
                hb_curve,
            )

            for method, (generated, estimated_curve) in method_outputs.items():
                metric_rng = np.random.default_rng(args.seed + repeat * 1009 + k * 17)
                precision, coverage = support_metrics(generated, true_curve)
                rows.append(
                    {
                        "repeat": repeat,
                        "k": k,
                        "method": method,
                        "swd": sliced_wasserstein(generated, truth, metric_rng),
                        "energy": energy_distance(generated, truth),
                        "support_precision": precision,
                        "support_coverage": coverage,
                        "curve_error": curve_error(estimated_curve, true_curve) if estimated_curve is not None else None,
                    }
                )
            if repeat == 0 and k == 5:
                example = {
                    # Keep the complete ambient-dimensional arrays.  Visualizers
                    # must use one shared projection learned from the true curve;
                    # plotting the first two coordinates can hide differences.
                    "shots": shot_x.tolist(),
                    "truth": truth.tolist(),
                    "true_curve": true_curve.tolist(),
                    "naive_curve": naive_curve.tolist(),
                    "naive_samples": method_outputs["Naive TPM"][0].tolist(),
                    "hb_curve": hb_curve.tolist(),
                    "vae": method_outputs["Source-adapted VAE"][0].tolist(),
                    "hb_samples": method_outputs["HB-TPM"][0].tolist(),
                }

    summary = summarize(rows)
    best_counts: dict[str, int] = {}
    for k in args.k_values:
        for repeat in range(args.repeats):
            group = [r for r in rows if r["k"] == k and r["repeat"] == repeat]
            best = min(group, key=lambda r: r["swd"])["method"]
            best_counts[best] = best_counts.get(best, 0) + 1

    # Correct-model sanity check: on Gaussian data, the Gaussian MLE should win.
    gaussian_control = []
    for repeat in range(args.repeats):
        ctrl_rng = np.random.default_rng(args.seed + 900_000 + repeat)
        mu = ctrl_rng.normal(0.0, 0.3, size=oracle.ambient_dim)
        diag = np.linspace(0.02, 0.08, oracle.ambient_dim)
        for k in args.k_values:
            shots = ctrl_rng.normal(mu, diag, size=(k, oracle.ambient_dim))
            truth = ctrl_rng.normal(mu, diag, size=(args.n_eval, oracle.ambient_dim))
            g = gaussian_sample(shots, args.n_eval, ctrl_rng)
            c = naive_tpm_curve(shots)
            tpm = sample_curve_grid(c, args.n_eval, float(np.mean(diag)), ctrl_rng)
            metric_rng = np.random.default_rng(args.seed + 910_000 + repeat * 31 + k)
            gaussian_control.append(
                {
                    "repeat": repeat,
                    "k": k,
                    "gaussian_swd": sliced_wasserstein(g, truth, metric_rng),
                    "naive_tpm_swd": sliced_wasserstein(tpm, truth, metric_rng),
                }
            )

    payload = {
        "config": {**vars(args), "out": str(args.out)},
        "protocol": {
            "source_tasks": args.n_source,
            "source_points_per_task": args.source_points,
            "target_repeats": args.repeats,
            "target_k": args.k_values,
            "ambient_dimension": oracle.ambient_dim,
            "primary_metric": "sliced Wasserstein distance (lower is better)",
            "selection": "All settings fixed before target-test repeats; no target-oracle tuning.",
        },
        "learned_prior": {
            "noise_scale": prior.noise_scale,
            "mean_coefficient_variance": float(prior.variance.mean()),
        },
        "summary": summary,
        "best_counts": best_counts,
        "rows": rows,
        "gaussian_control": gaussian_control,
        "example": example,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"saved": str(args.out), "best_counts": best_counts}, indent=2))


if __name__ == "__main__":
    main()
