# Reproducible results

## Protocol

- Oracle: related smooth one-dimensional trajectories embedded in 8 dimensions, with task-specific trajectory coefficients and normal noise.
- Transfer data: 48 ordered source tasks, 96 points per task.
- Target evaluation: 30 independent held-out tasks; K in {3,5,10}; 192 fresh oracle samples and 192 generated samples per comparison.
- Primary metric: 64-projection sliced-Wasserstein distance (SWD), lower is better.
- Secondary metrics: energy distance, support precision/coverage distance, and symmetric curve Chamfer error.
- VAE baselines: a genuine nonlinear two-latent VAE trained only on target shots, and the same architecture pretrained on pooled source samples then anchored/fine-tuned on target shots.
- No target-oracle quantity is used to tune a fitted target model. The target truth is used only for evaluation.

## Primary comparison

Values are mean +/- standard error across 30 held-out tasks.

| K | HB-TPM SWD | Source-adapted VAE SWD | Relative reduction | Paired wins | Exact one-sided sign test |
|---:|---:|---:|---:|---:|---:|
| 3 | 0.1180 +/- 0.0045 | 0.1494 +/- 0.0037 | 21.0% | 28/30 | p = 4.34e-7 |
| 5 | 0.0934 +/- 0.0047 | 0.1340 +/- 0.0033 | 30.2% | 28/30 | p = 4.34e-7 |
| 10 | 0.0739 +/- 0.0031 | 0.1270 +/- 0.0033 | 41.8% | 30/30 | p = 9.31e-10 |

For context, target-only VAE SWD is 0.2762, 0.2004, and 0.1783; Gaussian SWD is 0.2687, 0.2089, and 0.1786; naive TPM SWD is 0.2910, 0.1945, and 0.1539.

## Support recovery

| K | Method | Support precision distance | Support coverage distance | Energy distance |
|---:|---|---:|---:|---:|
| 3 | HB-TPM | 0.2584 | 0.2579 | 0.0877 |
| 3 | Source-adapted VAE | 0.3824 | 0.2944 | 0.1273 |
| 5 | HB-TPM | 0.1747 | 0.1723 | 0.0519 |
| 5 | Source-adapted VAE | 0.3476 | 0.2295 | 0.1026 |
| 10 | HB-TPM | 0.0904 | 0.0909 | 0.0265 |
| 10 | Source-adapted VAE | 0.3304 | 0.1899 | 0.0885 |

## Ablation: where the gain comes from

Symmetric curve Chamfer error:

| K | HB-TPM | HB-TPM without effective shrinkage | Naive TPM |
|---:|---:|---:|---:|
| 3 | 0.2588 | 0.3047 | 0.4170 |
| 5 | 0.1717 | 0.2957 | 0.2838 |
| 10 | 0.0845 | 0.1623 | 0.1825 |

The main gain is the hierarchical source prior, especially when the target design is underdetermined. Tangent-normal versus matched-radial isotropic noise changes SWD very little at K=3 and K=5; at K=10 the isotropic variant happens to have lower SWD despite the same curve. Therefore anisotropic noise is not the empirical origin of the primary advantage in this benchmark.

## Negative control

When the oracle is a full-dimensional diagonal Gaussian, the correctly specified Gaussian estimator beats naive TPM in 82 of 90 comparisons. Mean Gaussian-versus-naive SWD is 0.0347 versus 0.0406 at K=3, 0.0290 versus 0.0341 at K=5, and 0.0213 versus 0.0254 at K=10.

This negative control is part of the conclusion: HB-TPM has an advantage for transferable trajectory families, not for arbitrary distributions.

## Conclusion

If source data provide repeated ordered trajectories from the same family, a low-dimensional hierarchical posterior can recover a held-out trajectory more sample-efficiently than a conventional VAE that models pooled density without the ordering signal.

The advantage originates in information, not in the word “manifold”: source ordering plus a shared trajectory family turns an impossible nonparametric problem into a shrinkage problem with finite posterior variance. A conditional/meta VAE given the same trajectory supervision could plausibly close the gap; that is the next strong baseline required before an image-paper claim.
