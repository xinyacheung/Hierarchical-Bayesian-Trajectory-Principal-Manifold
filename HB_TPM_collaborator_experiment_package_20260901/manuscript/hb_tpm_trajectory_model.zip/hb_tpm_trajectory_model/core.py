from __future__ import annotations

from dataclasses import dataclass
from math import comb
from typing import Iterable

import numpy as np


def _oracle_basis(t: np.ndarray) -> np.ndarray:
    """Basis used only by the simulator; estimators never call this function."""
    t = np.asarray(t, dtype=np.float64).reshape(-1)
    u = 2.0 * t - 1.0
    return np.column_stack(
        [
            np.ones_like(t),
            u,
            np.sin(np.pi * u),
            np.cos(np.pi * u),
            np.sin(2.0 * np.pi * u),
            np.cos(2.0 * np.pi * u),
        ]
    )


def _oracle_basis_derivative(t: np.ndarray) -> np.ndarray:
    t = np.asarray(t, dtype=np.float64).reshape(-1)
    u = 2.0 * t - 1.0
    return np.column_stack(
        [
            np.zeros_like(t),
            np.full_like(t, 2.0),
            2.0 * np.pi * np.cos(np.pi * u),
            -2.0 * np.pi * np.sin(np.pi * u),
            4.0 * np.pi * np.cos(2.0 * np.pi * u),
            -4.0 * np.pi * np.sin(2.0 * np.pi * u),
        ]
    )


def trajectory_basis(t: np.ndarray) -> np.ndarray:
    """Generic degree-9 Bernstein basis used by HB-TPM.

    This is deliberately different from ``_oracle_basis``.  Source ordering is
    used to estimate the family coefficients; the estimator is not handed the
    simulator's Fourier representation.
    """
    t = np.asarray(t, dtype=np.float64).reshape(-1)
    degree = 9
    return np.column_stack(
        [comb(degree, k) * t**k * (1.0 - t) ** (degree - k) for k in range(degree + 1)]
    )


def trajectory_basis_derivative(t: np.ndarray) -> np.ndarray:
    t = np.asarray(t, dtype=np.float64).reshape(-1)
    degree = 9
    lower = [comb(degree - 1, k) * t**k * (1.0 - t) ** (degree - 1 - k) for k in range(degree)]
    columns = []
    for k in range(degree + 1):
        left = lower[k - 1] if k > 0 else np.zeros_like(t)
        right = lower[k] if k < degree else np.zeros_like(t)
        columns.append(degree * (left - right))
    return np.column_stack(columns)


@dataclass(frozen=True)
class TrajectoryTask:
    w: np.ndarray
    t: np.ndarray
    x: np.ndarray

    def curve(self, grid: np.ndarray) -> np.ndarray:
        return _oracle_basis(grid) @ self.w


@dataclass(frozen=True)
class HierarchicalPrior:
    mean: np.ndarray
    variance: np.ndarray
    noise_scale: float


class TrajectoryOracle:
    """A family of related nonlinear trajectories embedded in an ambient space."""

    def __init__(self, ambient_dim: int = 8, task_scale: float = 0.10, noise_scale: float = 0.035):
        self.ambient_dim = ambient_dim
        self.task_scale = task_scale
        self.noise_scale = noise_scale
        rng = np.random.default_rng(20260822)
        raw = rng.normal(size=(ambient_dim, ambient_dim))
        q, _ = np.linalg.qr(raw)
        latent_coeff = np.zeros((6, ambient_dim), dtype=np.float64)
        # A non-self-intersecting S/arc trajectory in three intrinsic coordinates.
        latent_coeff[1, 0] = 1.20
        latent_coeff[2, 1] = 0.38
        latent_coeff[3, 1] = 0.72
        latent_coeff[4, 2] = 0.16
        latent_coeff[5, 2] = 0.32
        self.base_w = latent_coeff @ q
        # Task variation is smooth and coefficient-specific, not arbitrary ambient noise.
        scale = np.array([0.10, 0.07, 0.09, 0.09, 0.055, 0.055])[:, None]
        self.coefficient_scale = task_scale * scale / 0.10

    def draw_task(self, rng: np.random.Generator, n: int, ordered: bool = False) -> TrajectoryTask:
        w = self.base_w + rng.normal(size=self.base_w.shape) * self.coefficient_scale
        t = rng.uniform(0.0, 1.0, size=n)
        if ordered:
            t.sort()
        center = _oracle_basis(t) @ w
        x = add_normal_noise(center, t, w, self.noise_scale, rng, _oracle_basis_derivative)
        return TrajectoryTask(w=w, t=t, x=x)

    def resample(self, task: TrajectoryTask, rng: np.random.Generator, n: int) -> tuple[np.ndarray, np.ndarray]:
        t = rng.uniform(0.0, 1.0, size=n)
        center = _oracle_basis(t) @ task.w
        return add_normal_noise(center, t, task.w, self.noise_scale, rng, _oracle_basis_derivative), t


def add_normal_noise(
    center: np.ndarray,
    t: np.ndarray,
    w: np.ndarray,
    scale: float,
    rng: np.random.Generator,
    derivative=trajectory_basis_derivative,
) -> np.ndarray:
    tangent = derivative(t) @ w
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-12)
    noise = rng.normal(size=center.shape)
    noise -= (noise * tangent).sum(axis=1, keepdims=True) * tangent
    noise /= np.maximum(np.linalg.norm(noise, axis=1, keepdims=True), 1e-12)
    amplitude = rng.normal(0.0, scale, size=(len(center), 1))
    return center + amplitude * noise


def learn_hierarchical_prior(source_tasks: Iterable[TrajectoryTask], ridge: float = 1e-6) -> HierarchicalPrior:
    fitted: list[np.ndarray] = []
    residuals: list[float] = []
    for task in source_tasks:
        phi = trajectory_basis(task.t)
        gram = phi.T @ phi + ridge * np.eye(phi.shape[1])
        w = np.linalg.solve(gram, phi.T @ task.x)
        fitted.append(w)
        residuals.extend(np.linalg.norm(task.x - phi @ w, axis=1).tolist())
    stack = np.stack(fitted)
    mean = stack.mean(axis=0)
    variance = stack.var(axis=0, ddof=1)
    variance = np.maximum(variance, 2.5e-4)
    # Median radial residual is stable against occasional source outliers.
    noise_scale = float(np.median(residuals) / 0.6745)
    noise_scale = float(np.clip(noise_scale, 0.015, 0.08))
    return HierarchicalPrior(mean=mean, variance=variance, noise_scale=noise_scale)


def fit_hb_tpm(
    x: np.ndarray,
    prior: HierarchicalPrior,
    prior_multiplier: float = 1.0,
    grid_size: int = 401,
    n_iter: int = 20,
) -> tuple[np.ndarray, np.ndarray]:
    """MAP curve fit with latent projection indices and source-learned shrinkage."""
    grid = np.linspace(0.0, 1.0, grid_size)
    phi_grid = trajectory_basis(grid)
    w = prior.mean.copy()
    variance = np.maximum(prior.variance * prior_multiplier, 1e-7)
    noise2 = max(prior.noise_scale**2, 1e-6)
    last_idx = None
    for _ in range(n_iter):
        curve = phi_grid @ w
        d2 = ((x[:, None, :] - curve[None, :, :]) ** 2).sum(axis=2)
        idx = np.argmin(d2, axis=1)
        phi = phi_grid[idx]
        for d in range(x.shape[1]):
            precision = np.diag(1.0 / variance[:, d])
            lhs = phi.T @ phi / noise2 + precision
            rhs = phi.T @ x[:, d] / noise2 + precision @ prior.mean[:, d]
            w[:, d] = np.linalg.solve(lhs, rhs)
        if last_idx is not None and np.array_equal(idx, last_idx):
            break
        last_idx = idx.copy()
    return w, grid[idx]


def sample_hb_tpm(
    w: np.ndarray,
    n: int,
    noise_scale: float,
    rng: np.random.Generator,
    isotropic: bool = False,
) -> np.ndarray:
    t = rng.uniform(0.0, 1.0, size=n)
    center = trajectory_basis(t) @ w
    if isotropic:
        # Match expected radial noise but spend it across all ambient directions.
        return center + rng.normal(0.0, noise_scale / np.sqrt(center.shape[1]), size=center.shape)
    return add_normal_noise(center, t, w, noise_scale, rng)


def gaussian_sample(x: np.ndarray, n: int, rng: np.random.Generator) -> np.ndarray:
    d = x.shape[1]
    if len(x) == 1:
        cov = np.eye(d) * 1e-3
    else:
        centered = x - x.mean(axis=0)
        cov = centered.T @ centered / max(len(x) - 1, 1)
        avg_var = max(float(np.trace(cov) / d), 1e-5)
        shrink = min(0.55, d / max(d + len(x), 1))
        cov = (1.0 - shrink) * cov + shrink * avg_var * np.eye(d)
    return rng.multivariate_normal(x.mean(axis=0), cov + np.eye(d) * 1e-6, size=n)


def smote_sample(x: np.ndarray, n: int, rng: np.random.Generator) -> np.ndarray:
    a = x[rng.integers(0, len(x), size=n)]
    b = x[rng.integers(0, len(x), size=n)]
    lam = rng.uniform(0.0, 1.0, size=(n, 1))
    return (1.0 - lam) * a + lam * b


def naive_tpm_curve(x: np.ndarray, grid_size: int = 401) -> np.ndarray:
    if len(x) == 1:
        return np.repeat(x, grid_size, axis=0)
    centered = x - x.mean(axis=0)
    _, _, vh = np.linalg.svd(centered, full_matrices=False)
    ordered = x[np.argsort(centered @ vh[0])]
    seg = np.linalg.norm(np.diff(ordered, axis=0), axis=1)
    knots = np.concatenate([[0.0], np.cumsum(seg)])
    if knots[-1] <= 1e-12:
        return np.repeat(ordered[:1], grid_size, axis=0)
    knots /= knots[-1]
    grid = np.linspace(0.0, 1.0, grid_size)
    return np.column_stack([np.interp(grid, knots, ordered[:, d]) for d in range(x.shape[1])])


def sample_curve_grid(curve: np.ndarray, n: int, noise_scale: float, rng: np.random.Generator) -> np.ndarray:
    idx = rng.integers(0, len(curve), size=n)
    center = curve[idx]
    tangent_grid = np.gradient(curve, axis=0)
    tangent = tangent_grid[idx]
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-12)
    noise = rng.normal(size=center.shape)
    noise -= (noise * tangent).sum(axis=1, keepdims=True) * tangent
    noise /= np.maximum(np.linalg.norm(noise, axis=1, keepdims=True), 1e-12)
    return center + rng.normal(0.0, noise_scale, size=(n, 1)) * noise


def pairwise_dist(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    aa = (a * a).sum(axis=1)[:, None]
    bb = (b * b).sum(axis=1)[None, :]
    return np.sqrt(np.maximum(aa + bb - 2.0 * a @ b.T, 0.0))


def sliced_wasserstein(a: np.ndarray, b: np.ndarray, rng: np.random.Generator, n_proj: int = 64) -> float:
    n = min(len(a), len(b))
    a = a[:n]
    b = b[:n]
    directions = rng.normal(size=(n_proj, a.shape[1]))
    directions /= np.maximum(np.linalg.norm(directions, axis=1, keepdims=True), 1e-12)
    pa = np.sort(a @ directions.T, axis=0)
    pb = np.sort(b @ directions.T, axis=0)
    return float(np.sqrt(np.mean((pa - pb) ** 2)))


def energy_distance(a: np.ndarray, b: np.ndarray) -> float:
    return float(2.0 * pairwise_dist(a, b).mean() - pairwise_dist(a, a).mean() - pairwise_dist(b, b).mean())


def support_metrics(generated: np.ndarray, true_curve: np.ndarray) -> tuple[float, float]:
    d = pairwise_dist(generated, true_curve)
    precision_distance = float(d.min(axis=1).mean())
    coverage_distance = float(d.min(axis=0).mean())
    return precision_distance, coverage_distance


def curve_error(estimated_curve: np.ndarray, true_curve: np.ndarray) -> float:
    d = pairwise_dist(estimated_curve, true_curve)
    return float(0.5 * (d.min(axis=1).mean() + d.min(axis=0).mean()))


class NumpyVAE:
    """Small genuine nonlinear VAE, implemented in NumPy for a dependency-free baseline."""

    def __init__(self, input_dim: int, hidden_dim: int = 24, latent_dim: int = 2, seed: int = 0):
        rng = np.random.default_rng(seed)
        self.params = {
            "we": rng.normal(0.0, 0.16, size=(input_dim, hidden_dim)),
            "be": np.zeros(hidden_dim),
            "wmu": rng.normal(0.0, 0.12, size=(hidden_dim, latent_dim)),
            "bmu": np.zeros(latent_dim),
            "wlv": rng.normal(0.0, 0.04, size=(hidden_dim, latent_dim)),
            "blv": np.full(latent_dim, -1.0),
            "wd": rng.normal(0.0, 0.16, size=(latent_dim, hidden_dim)),
            "bd": np.zeros(hidden_dim),
            "wo": rng.normal(0.0, 0.12, size=(hidden_dim, input_dim)),
            "bo": np.zeros(input_dim),
        }

    def copy(self) -> "NumpyVAE":
        out = NumpyVAE(self.params["we"].shape[0], self.params["we"].shape[1], self.params["wmu"].shape[1])
        out.params = {k: v.copy() for k, v in self.params.items()}
        return out

    def fit(
        self,
        x: np.ndarray,
        steps: int,
        batch_size: int,
        lr: float,
        beta: float,
        seed: int,
        anchor: dict[str, np.ndarray] | None = None,
        anchor_strength: float = 0.0,
    ) -> None:
        rng = np.random.default_rng(seed)
        m = {k: np.zeros_like(v) for k, v in self.params.items()}
        v = {k: np.zeros_like(vv) for k, vv in self.params.items()}
        for step in range(1, steps + 1):
            idx = rng.integers(0, len(x), size=min(batch_size, max(len(x), 1)))
            batch = x[idx]
            grads = self._grads(batch, beta, rng)
            if anchor is not None and anchor_strength > 0:
                for key in grads:
                    grads[key] += anchor_strength * (self.params[key] - anchor[key])
            for key in self.params:
                grad = np.clip(grads[key], -5.0, 5.0)
                m[key] = 0.9 * m[key] + 0.1 * grad
                v[key] = 0.999 * v[key] + 0.001 * grad * grad
                mh = m[key] / (1.0 - 0.9**step)
                vh = v[key] / (1.0 - 0.999**step)
                self.params[key] -= lr * mh / (np.sqrt(vh) + 1e-8)

    def _grads(self, x: np.ndarray, beta: float, rng: np.random.Generator) -> dict[str, np.ndarray]:
        p = self.params
        he = np.tanh(x @ p["we"] + p["be"])
        mu = he @ p["wmu"] + p["bmu"]
        lv_raw = he @ p["wlv"] + p["blv"]
        lv = np.clip(lv_raw, -6.0, 3.0)
        std = np.exp(0.5 * lv)
        eps = rng.normal(size=mu.shape)
        z = mu + std * eps
        hd = np.tanh(z @ p["wd"] + p["bd"])
        out = hd @ p["wo"] + p["bo"]
        n = len(x)
        dout = (out - x) / n
        grads: dict[str, np.ndarray] = {}
        grads["wo"] = hd.T @ dout
        grads["bo"] = dout.sum(axis=0)
        dhd = (dout @ p["wo"].T) * (1.0 - hd * hd)
        grads["wd"] = z.T @ dhd
        grads["bd"] = dhd.sum(axis=0)
        dz = dhd @ p["wd"].T
        dmu = dz + beta * mu / n
        dlv = dz * eps * 0.5 * std + beta * 0.5 * (np.exp(lv) - 1.0) / n
        dlv *= ((lv_raw > -6.0) & (lv_raw < 3.0))
        grads["wmu"] = he.T @ dmu
        grads["bmu"] = dmu.sum(axis=0)
        grads["wlv"] = he.T @ dlv
        grads["blv"] = dlv.sum(axis=0)
        dhe = dmu @ p["wmu"].T + dlv @ p["wlv"].T
        dhe *= 1.0 - he * he
        grads["we"] = x.T @ dhe
        grads["be"] = dhe.sum(axis=0)
        return grads

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        p = self.params
        z = rng.normal(size=(n, p["wmu"].shape[1]))
        hd = np.tanh(z @ p["wd"] + p["bd"])
        return hd @ p["wo"] + p["bo"]
