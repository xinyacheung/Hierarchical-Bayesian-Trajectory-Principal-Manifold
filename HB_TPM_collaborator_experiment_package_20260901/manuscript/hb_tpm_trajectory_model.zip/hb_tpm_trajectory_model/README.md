# HB-TPM trajectory model

This folder contains an independent, reproducible implementation of HB-TPM and its oracle trajectory benchmark. The original project files remain untouched.

## Method

`HB-TPM` is a Hierarchical Bayesian Trajectory Principal-Manifold model. It learns a distribution of smooth trajectory coefficients from ordered source tasks, assigns latent progression indices to sparse unordered target shots, performs a MAP update, and samples with a source-calibrated normal tube.

The essential modeling condition is identifiability: arbitrary curves cannot be recovered from a few unordered points. HB-TPM applies when target trajectories belong to a transferable source-learned family, with an explicit fallback gate when that assumption fails.

## Reproduce

```bash
/Users/xin-yazhang/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  hb_tpm_trajectory_model/run_experiment.py \
  --repeats 30 --k-values 3 5 10 \
  --out hb_tpm_trajectory_model/results/benchmark.json

/Users/xin-yazhang/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  hb_tpm_trajectory_model/make_final_artifacts.py
```

The benchmark compares Gaussian, SMOTE, naive TPM, a genuine target-only nonlinear VAE, a source-pretrained and target-adapted nonlinear VAE, HB-TPM, and two HB-TPM ablations. Every method receives the same target shots. Both transfer methods receive the same pooled source samples; HB-TPM additionally uses the source ordering signal, which is the structural assumption being tested.

## Main result

Across 30 held-out target tasks for each K, HB-TPM beats the source-adapted VAE on sliced-Wasserstein distance in 86 of 90 paired comparisons. Mean SWD is 0.1180, 0.0934, and 0.0739 for K=3,5,10, versus 0.1494, 0.1340, and 0.1270 for source-adapted VAE. The relative reductions are 21.0%, 30.2%, and 41.8%.

The simulator and estimator no longer share a basis: the oracle uses a private Fourier representation, while HB-TPM uses a generic degree-9 Bernstein basis. This is a deliberately stricter model-mismatch check than the earlier version.

The Gaussian negative control is also important: under a correctly specified Gaussian oracle, Gaussian estimation beats naive TPM in 82 of 90 comparisons. The method claim is therefore conditional on a transferable trajectory family, not universal.
