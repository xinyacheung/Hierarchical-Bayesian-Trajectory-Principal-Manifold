from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image as RLImage,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parent
RESULT_JSON = ROOT / "results" / "benchmark.json"
OUT = ROOT / "final_package"
METHOD_FLOW_FIG = OUT / "00_method_flow.png"
METHOD_FIG = OUT / "01_method_and_code_map.png"
VISUAL_FIG = OUT / "02_visual_recovery_K5.png"
BENCHMARK_FIG = OUT / "03_benchmark_summary.png"
REPORT_PDF = OUT / "HB_TPM_report.pdf"

FONT_LIGHT = "/System/Library/Fonts/STHeiti Light.ttc"
FONT_MEDIUM = "/System/Library/Fonts/STHeiti Medium.ttc"
PLOT_FONT = "/System/Library/Fonts/Supplemental/Arial.ttf"
PLOT_FONT_BOLD = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
BLUE = "#185ADB"
NAVY = "#152A55"
TEAL = "#168B82"
RED = "#D94A64"
ORANGE = "#E58A2B"
INK = "#172033"
MUTED = "#596274"
GRID = "#DDE3EC"
YELLOW = "#FFD54A"


def pil_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_MEDIUM if bold else FONT_LIGHT, size=size, index=0)


def plot_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(PLOT_FONT_BOLD if bold else PLOT_FONT, size=size)


def rounded(draw: ImageDraw.ImageDraw, box, fill, outline, radius=24, width=3):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def centered(draw: ImageDraw.ImageDraw, box, text, size, fill=INK, bold=False):
    x = (box[0] + box[2]) / 2
    y = (box[1] + box[3]) / 2
    draw.text((x, y), text, font=pil_font(size, bold), fill=fill, anchor="mm", align="center")


def arrow(draw: ImageDraw.ImageDraw, x1, y1, x2, y2, color="#7A8495"):
    draw.line((x1, y1, x2, y2), fill=color, width=6)
    draw.polygon([(x2, y2), (x2 - 18, y2 - 11), (x2 - 18, y2 + 11)], fill=color)


def draw_demo_curve(draw: ImageDraw.ImageDraw, box, color, offset=0, width=7, points=False):
    left, top, right, bottom = box
    coords = []
    for i in range(120):
        u = i / 119
        x = left + u * (right - left)
        y = (top + bottom) / 2 + 0.30 * (bottom - top) * np.sin(1.65 * np.pi * u + 0.15) - 0.18 * (bottom - top) * u + offset
        coords.append((int(x), int(y)))
    draw.line(coords, fill=color, width=width, joint="curve")
    if points:
        for idx in (9, 31, 55, 81, 108):
            x, y = coords[idx]
            draw.ellipse((x-7, y-7, x+7, y+7), fill=YELLOW, outline="#111827", width=2)
    return coords


def make_method_flow_figure() -> None:
    image = Image.new("RGB", (2800, 1580), "white")
    d = ImageDraw.Draw(image)
    d.text((90, 55), "HB-TPM — method flow", font=pil_font(58, True), fill=INK)
    d.text((92, 132), "Offline source learning supplies identifiable structure; each sparse target only performs posterior adaptation.", font=pil_font(30), fill=MUTED)

    # Source lane.
    rounded(d, (70, 230, 2730, 690), "#F3F7FF", "#BED0F4", radius=28, width=3)
    d.text((105, 260), "OFFLINE  |  ordered source learning", font=pil_font(31, True), fill=NAVY)
    source_boxes = [(120, 350, 690, 620), (860, 350, 1430, 620), (1600, 350, 2220, 620), (2350, 350, 2660, 620)]
    source_titles = ["1  Ordered source tasks", "2  Generic smooth basis", "3  Fit task coefficients", "4  Family prior"]
    source_body = ["observe (t, x)\ntime / pseudotime known", "Phi(t): degree-9 Bernstein\nindependent of oracle basis", "W_j from each trajectory\nsource residual scale", "W0, Lambda, sigma\ntransferable structure"]
    for box, title, body in zip(source_boxes, source_titles, source_body):
        rounded(d, box, "white", "#9EB8EA", radius=20, width=2)
        d.text((box[0]+22, box[1]+18), title, font=pil_font(27, True), fill=INK)
        d.multiline_text((box[0]+22, box[1]+72), body, font=pil_font(23), fill=MUTED, spacing=13)
    draw_demo_curve(d, (155, 510, 645, 590), BLUE, -18, 5, True)
    draw_demo_curve(d, (155, 520, 645, 600), TEAL, 18, 5, False)
    for a,b in zip(source_boxes[:-1], source_boxes[1:]): arrow(d, a[2]+18, 485, b[0]-18, 485)

    # Transfer arrow.
    d.line((2505, 690, 2505, 785), fill=BLUE, width=8)
    d.polygon([(2505, 815), (2486, 780), (2524, 780)], fill=BLUE)
    d.text((2545, 748), "prior transfer", font=pil_font(25, True), fill=BLUE, anchor="lm")

    # Target lane.
    rounded(d, (70, 815, 2730, 1370), "#FAFCFB", "#B7D9D4", radius=28, width=3)
    d.text((105, 845), "PER TARGET  |  K unordered shots", font=pil_font(31, True), fill="#0E7069")
    target_boxes = [(120, 945, 630, 1280), (790, 945, 1660, 1280), (1820, 945, 2240, 1280), (2400, 945, 2670, 1280)]
    titles = ["5  Sparse target", "6  Alternating posterior inference", "7  Target curve", "8  Samples"]
    bodies = ["x_i only\nlatent t_i unknown", "E-like step: project x_i -> t_i\nM-like step: MAP update W\nrepeat until indices stabilize", "gamma_hat(t)=Phi(t)W*\nposterior-shrunk estimate", "sample t\nadd calibrated noise"]
    for box,title,body in zip(target_boxes,titles,bodies):
        rounded(d, box, "white", "#8FC8C1", radius=20, width=2)
        d.text((box[0]+22,box[1]+18),title,font=pil_font(27,True),fill=INK)
        d.multiline_text((box[0]+22,box[1]+76),body,font=pil_font(23),fill=MUTED,spacing=13)
    # Unordered target points.
    for x,y in [(185,1160),(290,1040),(410,1190),(515,1065),(570,1210)]:
        d.ellipse((x-13,y-13,x+13,y+13),fill=YELLOW,outline="#111827",width=3)
    # Alternation loop.
    d.rounded_rectangle((845, 1125, 1605, 1228), radius=18, fill="#EAF7F5", outline=TEAL, width=3)
    d.text((1225, 1176), "latent ordering  <---->  coefficient MAP", font=pil_font(25, True), fill="#0E7069", anchor="mm")
    draw_demo_curve(d, (1850, 1110, 2210, 1235), BLUE, 0, 7, True)
    curve = draw_demo_curve(d, (2420, 1100, 2645, 1225), BLUE, 0, 5, False)
    for idx in (8,22,38,54,70,86,102,116):
        x,y=curve[idx]
        d.ellipse((x-7,y-7,x+7,y+7),fill="#8DB4FF",outline=BLUE,width=2)
    for a,b in zip(target_boxes[:-1], target_boxes[1:]): arrow(d, a[2]+18, 1110, b[0]-18, 1110, TEAL)

    rounded(d, (250, 1430, 2550, 1530), NAVY, NAVY, radius=22)
    centered(d, (250, 1430, 2550, 1530), "Identifiability comes from source ordering + hierarchical shrinkage — not from the sampling tube.", 31, "white", True)
    image.save(METHOD_FLOW_FIG, quality=96)


def make_method_figure() -> None:
    canvas = Image.new("RGB", (2400, 1320), "white")
    d = ImageDraw.Draw(canvas)
    d.text((80, 55), "HB-TPM：方法与代码一一对应", font=pil_font(54, True), fill=INK)
    d.text((82, 125), "关键变化：不再从 K 个无序点凭空恢复任意曲线，而是用有序 source 学到轨迹族先验。", font=pil_font(30), fill=MUTED)

    boxes = [(70, 245, 480, 660), (550, 245, 960, 660), (1030, 245, 1440, 660), (1510, 245, 1920, 660), (1990, 245, 2330, 660)]
    fills = ["#F2F5FA", "#EAF1FF", "#FFF6DA", "#EAF7F5", "#EDF3FF"]
    outlines = ["#AAB4C4", BLUE, "#D6A31F", TEAL, BLUE]
    titles = ["1  模拟 / source 数据", "2  学轨迹族先验", "3  稀疏 target", "4  后验 MAP 拟合", "5  生成样本"]
    bodies = [
        "有序 (t, x)\n48 tasks × 96 points\n\nTrajectoryOracle.draw_task",
        "估计 W0、Lambda、sigma\n通用 Bernstein basis\n\nlearn_hierarchical_prior",
        "只有 K 个无序 x_i\nK = 3, 5, 10\n\nshot_x",
        "交替更新 latent t_i\n与曲线系数 W*\n\nfit_hb_tpm",
        "沿曲线均匀取 t\n加入法向噪声\n\nsample_hb_tpm",
    ]
    for box, fill, outline, title, body in zip(boxes, fills, outlines, titles, bodies):
        rounded(d, box, fill, outline)
        d.text((box[0] + 24, box[1] + 24), title, font=pil_font(29, True), fill=INK)
        d.multiline_text((box[0] + 24, box[1] + 96), body, font=pil_font(25), fill="#354052", spacing=20)
    for left, right in zip(boxes[:-1], boxes[1:]):
        arrow(d, left[2] + 8, 455, right[0] - 8, 455)

    rounded(d, (95, 735, 2305, 855), NAVY, NAVY, radius=22)
    centered(d, (95, 735, 2305, 855), "优势来源 = source ordering 提供可迁移结构  +  层级后验 shrinkage 限制低样本自由度", 34, "white", True)

    d.text((80, 920), "代码入口与数据流", font=pil_font(38, True), fill=INK)
    code_boxes = [
        (80, 995, 530, 1215, "run_experiment.py", "构造 source / target\n训练 VAE baselines\n计算全部指标"),
        (625, 995, 1110, 1215, "core.py", "oracle（仅模拟）\nprior / MAP / sampler\nVAE 与 metrics"),
        (1205, 995, 1690, 1215, "results/benchmark.json", "完整 30×3 配对结果\n8D 示例数组\n配置与 negative control"),
        (1785, 995, 2320, 1215, "make_final_artifacts.py", "共享 PCA 投影\n结果图与本 PDF\n视觉核验入口"),
    ]
    for x1, y1, x2, y2, title, body in code_boxes:
        rounded(d, (x1, y1, x2, y2), "#FAFBFD", "#C6CEDA", radius=18, width=2)
        d.text((x1 + 20, y1 + 20), title, font=pil_font(26, True), fill=NAVY)
        d.multiline_text((x1 + 20, y1 + 72), body, font=pil_font(22), fill="#465064", spacing=12)
    canvas.save(METHOD_FIG, quality=96)


def pca_projection(example: dict[str, list]) -> tuple[dict[str, np.ndarray], np.ndarray, np.ndarray]:
    arrays = {k: np.asarray(v, dtype=float) for k, v in example.items()}
    curve = arrays["true_curve"]
    center = curve.mean(axis=0)
    _, _, vt = np.linalg.svd(curve - center, full_matrices=False)
    basis = vt[:2].T
    projected = {k: (v - center) @ basis for k, v in arrays.items()}
    all_z = np.vstack([projected["truth"], projected["naive_samples"], projected["vae"], projected["hb_samples"]])
    lo = np.quantile(all_z, 0.005, axis=0)
    hi = np.quantile(all_z, 0.995, axis=0)
    pad = 0.08 * (hi - lo)
    return projected, lo - pad, hi + pad


def example_metric(payload: dict, method: str) -> float:
    row = next(r for r in payload["rows"] if r["repeat"] == 0 and r["k"] == 5 and r["method"] == method)
    return float(row["swd"])


def map_points(a: np.ndarray, box, lo: np.ndarray, hi: np.ndarray) -> list[tuple[int, int]]:
    left, top, right, bottom = box
    x = left + (a[:, 0] - lo[0]) / max(hi[0] - lo[0], 1e-12) * (right - left)
    y = bottom - (a[:, 1] - lo[1]) / max(hi[1] - lo[1], 1e-12) * (bottom - top)
    return [(int(px), int(py)) for px, py in zip(x, y)]


def scatter_rgba(base: Image.Image, points: list[tuple[int, int]], color: tuple[int, int, int, int], radius: int = 5) -> None:
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    for x, y in points:
        draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=color)
    base.alpha_composite(layer)


def make_visual_figure(payload: dict) -> None:
    z, lo, hi = pca_projection(payload["example"])
    image = Image.new("RGBA", (2400, 650), "white")
    d = ImageDraw.Draw(image)
    panel_boxes = [(135, 70, 590, 530), (680, 70, 1135, 530), (1270, 70, 1725, 530), (1860, 70, 2315, 530)]
    panels = [
        ("(a) Oracle", None, None, "#6B7280"),
        ("(b) Naive TPM", "naive_samples", "naive_curve", ORANGE),
        ("(c) Source-adapted VAE", "vae", None, RED),
        ("(d) HB-TPM", "hb_samples", "hb_curve", BLUE),
    ]
    rgb = {ORANGE: (213, 126, 24, 76), RED: (190, 54, 70, 72), BLUE: (20, 78, 170, 76), "#6B7280": (92, 99, 110, 62)}
    x_ticks = np.linspace(lo[0], hi[0], 3)
    y_ticks = np.linspace(lo[1], hi[1], 3)
    for panel_idx, (box, (title, sample_key, curve_key, color)) in enumerate(zip(panel_boxes, panels)):
        left, top, right, bottom = box
        d.text((left, 14), title, font=plot_font(34, True), fill="#111111")
        d.rectangle(box, fill="#F3F5F7")
        # Light physics-style grid on a neutral panel background.
        for value in x_ticks:
            x = int(left + (value-lo[0]) / (hi[0]-lo[0]) * (right-left))
            d.line((x, top, x, bottom), fill="#D6DCE4", width=2)
        for value in y_ticks:
            y = int(bottom - (value-lo[1]) / (hi[1]-lo[1]) * (bottom-top))
            d.line((left, y, right, y), fill="#D6DCE4", width=2)
        d.line((left, top, left, bottom), fill="#111111", width=3)
        d.line((left, bottom, right, bottom), fill="#111111", width=3)
        for value in x_ticks:
            x = int(left + (value-lo[0]) / (hi[0]-lo[0]) * (right-left))
            d.line((x, bottom, x, bottom-10), fill="#111111", width=2)
            d.text((x, bottom+13), f"{value:.1f}", font=plot_font(26), fill="#222222", anchor="ma")
        for value in y_ticks:
            y = int(bottom - (value-lo[1]) / (hi[1]-lo[1]) * (bottom-top))
            d.line((left, y, left+10, y), fill="#111111", width=2)
            if panel_idx == 0:
                d.text((left-13, y), f"{value:.1f}", font=plot_font(26), fill="#222222", anchor="rm")
        d.text(((left+right)//2, 610), "PC 1", font=plot_font(30), fill="#111111", anchor="mm")
        true_pts = map_points(z["true_curve"], box, lo, hi)
        for i in range(0, len(true_pts)-8, 18):
            d.line(true_pts[i:i+10], fill="#151515", width=5)
        if sample_key is None:
            scatter_rgba(image, map_points(z["truth"], box, lo, hi), (80, 86, 96, 62), 5)
        else:
            scatter_rgba(image, map_points(z[sample_key], box, lo, hi), rgb[color], 5)
        if curve_key is not None:
            d.line(map_points(z[curve_key], box, lo, hi), fill=color, width=7, joint="curve")
        for x,y in map_points(z["shots"], box, lo, hi):
            d.ellipse((x-10,y-10,x+10,y+10), fill="#F0C74B", outline="#111111", width=3)
        if sample_key:
            method = {"naive_samples":"Naive TPM", "vae":"Source-adapted VAE", "hb_samples":"HB-TPM"}[sample_key]
            d.text((left+18, top+16), f"SWD {example_metric(payload, method):.3f}", font=plot_font(26), fill="#111111", anchor="la")
    ylabel = Image.new("RGBA", (140, 52), (0, 0, 0, 0))
    yd = ImageDraw.Draw(ylabel)
    yd.text((70, 26), "PC 2", font=plot_font(30), fill="#111111", anchor="mm")
    ylabel = ylabel.rotate(90, expand=True, resample=Image.Resampling.BICUBIC)
    image.alpha_composite(ylabel, (7, int((panel_boxes[0][1] + panel_boxes[0][3] - ylabel.height) / 2)))
    image.convert("RGB").save(VISUAL_FIG, quality=96)


def make_benchmark_figure(payload: dict) -> None:
    summary = payload["summary"]
    image = Image.new("RGB", (2400, 1050), "white")
    d = ImageDraw.Draw(image)
    d.text((75,45),"Oracle trajectory benchmark — 30 held-out tasks, mean ± SE",font=pil_font(43,True),fill=INK)
    palette = {
        "HB-TPM": BLUE,
        "Source-adapted VAE": RED,
        "Target-only VAE": "#9065C7",
        "Gaussian": "#3A9D5D",
        "Naive TPM": ORANGE,
        "HB-TPM no shrinkage": TEAL,
    }
    plot_boxes=[(120,220,1100,850),(1320,220,2300,850)]

    def plot_panel(box, title, ylabel, methods, metric, err_metric, ymax):
        left,top,right,bottom=box
        d.text((left,145),title,font=pil_font(31,True),fill=INK)
        for i in range(5):
            value=ymax*i/4; y=bottom-(bottom-top)*i/4
            d.line((left,y,right,y),fill="#E5EAF1",width=2)
            d.text((left-16,y),f"{value:.2f}",font=pil_font(20),fill=MUTED,anchor="rm")
        d.line((left,top,left,bottom),fill="#7E899A",width=3); d.line((left,bottom,right,bottom),fill="#7E899A",width=3)
        xs={3:left+110,5:(left+right)//2,10:right-110}
        for k,x in xs.items(): d.text((x,bottom+25),str(k),font=pil_font(22),fill=MUTED,anchor="ma")
        d.text(((left+right)//2,bottom+66),"target shots K",font=pil_font(22),fill=MUTED,anchor="ma")
        d.text((left+10,top+12),ylabel,font=pil_font(20),fill=MUTED)
        for method in methods:
            rows=sorted((r for r in summary if r["method"]==method),key=lambda r:r["k"])
            pts=[]
            for r in rows:
                x=xs[r["k"]]; y=bottom-r[metric]/ymax*(bottom-top); err=r[err_metric]/ymax*(bottom-top)
                d.line((x,y-err,x,y+err),fill=palette[method],width=3); d.line((x-8,y-err,x+8,y-err),fill=palette[method],width=3); d.line((x-8,y+err,x+8,y+err),fill=palette[method],width=3)
                pts.append((int(x),int(y)))
            d.line(pts,fill=palette[method],width=6,joint="curve")
            for x,y in pts: d.ellipse((x-8,y-8,x+8,y+8),fill=palette[method],outline="white",width=2)
        lx=left; ly=970
        for method in methods:
            item_width=82+len(method)*9
            if lx+item_width>right:
                lx=left; ly+=36
            d.line((lx,ly,lx+36,ly),fill=palette[method],width=6)
            d.text((lx+46,ly),method,font=pil_font(16),fill="#394354",anchor="lm")
            lx+=item_width

    plot_panel(plot_boxes[0],"A  Distribution recovery","sliced Wasserstein ↓",["HB-TPM","Source-adapted VAE","Target-only VAE","Gaussian","Naive TPM"],"swd_mean","swd_se",0.32)
    plot_panel(plot_boxes[1],"B  Curve recovery ablation","curve Chamfer error ↓",["HB-TPM","HB-TPM no shrinkage","Naive TPM"],"curve_error_mean","curve_error_se",0.46)
    image.save(BENCHMARK_FIG, quality=96)


def summary_row(payload: dict, k: int, method: str) -> dict:
    return next(r for r in payload["summary"] if r["k"] == k and r["method"] == method)


def paired_wins(payload: dict, k: int) -> int:
    hb = sorted((r for r in payload["rows"] if r["k"] == k and r["method"] == "HB-TPM"), key=lambda r: r["repeat"])
    vae = sorted((r for r in payload["rows"] if r["k"] == k and r["method"] == "Source-adapted VAE"), key=lambda r: r["repeat"])
    return sum(a["swd"] < b["swd"] for a, b in zip(hb, vae))


def register_pdf_fonts() -> None:
    pdfmetrics.registerFont(TTFont("Heiti", FONT_LIGHT, subfontIndex=0))
    pdfmetrics.registerFont(TTFont("HeitiBold", FONT_MEDIUM, subfontIndex=0))


def report_styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("title", parent=base["Title"], fontName="HeitiBold", fontSize=25, leading=33, textColor=colors.HexColor(NAVY), alignment=TA_LEFT, spaceAfter=7*mm),
        "subtitle": ParagraphStyle("subtitle", parent=base["Normal"], fontName="Heiti", fontSize=12, leading=18, textColor=colors.HexColor(MUTED), spaceAfter=5*mm),
        "h1": ParagraphStyle("h1", parent=base["Heading1"], fontName="HeitiBold", fontSize=17, leading=23, textColor=colors.HexColor(NAVY), spaceBefore=2*mm, spaceAfter=4*mm),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], fontName="HeitiBold", fontSize=12.5, leading=18, textColor=colors.HexColor(BLUE), spaceBefore=2*mm, spaceAfter=2*mm),
        "body": ParagraphStyle("body", parent=base["BodyText"], fontName="Heiti", fontSize=9.7, leading=15.5, textColor=colors.HexColor(INK), spaceAfter=2.5*mm),
        "small": ParagraphStyle("small", parent=base["BodyText"], fontName="Heiti", fontSize=8.2, leading=12.5, textColor=colors.HexColor(MUTED), spaceAfter=1.5*mm),
        "callout": ParagraphStyle("callout", parent=base["BodyText"], fontName="HeitiBold", fontSize=11.5, leading=18, textColor=colors.white, alignment=TA_CENTER),
        "card": ParagraphStyle("card", parent=base["BodyText"], fontName="Heiti", fontSize=9.2, leading=14, textColor=colors.HexColor(INK), alignment=TA_CENTER),
        "code": ParagraphStyle("code", parent=base["Code"], fontName="Courier", fontSize=7.8, leading=11.5, textColor=colors.HexColor("#273143")),
    }


def page_decor(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#D9E0EA")); canvas.setLineWidth(0.5)
    canvas.line(18*mm, 15*mm, 192*mm, 15*mm)
    canvas.setFont("Heiti", 7.5); canvas.setFillColor(colors.HexColor(MUTED))
    canvas.drawString(18*mm, 9.5*mm, "HB-TPM · trajectory-family transfer benchmark")
    canvas.drawRightString(192*mm, 9.5*mm, f"{doc.page}")
    canvas.restoreState()


def make_report(payload: dict) -> None:
    register_pdf_fonts()
    styles = report_styles()
    doc = BaseDocTemplate(str(REPORT_PDF), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=17*mm, bottomMargin=20*mm, title="HB-TPM 方法与结果报告", author="Codex")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")
    doc.addPageTemplates([PageTemplate(id="all", frames=[frame], onPage=page_decor)])
    story = []

    story += [Paragraph("HB-TPM：方法、代码与实验结果", styles["title"]), Paragraph("有序 source 轨迹迁移与极少样本生成 · 2026-08-25", styles["subtitle"])]
    callout = Table([[Paragraph("主要结果：当 source 提供有序轨迹且 target 与其属于同一轨迹族时，HB-TPM 在 30 个 held-out tasks、三个 K 设置中，对 source-adapted VAE 取得 86/90 配对胜场。", styles["callout"])]], colWidths=[174*mm])
    callout.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), colors.HexColor(NAVY)), ("BOX", (0,0), (-1,-1), 0, colors.HexColor(NAVY)), ("LEFTPADDING", (0,0), (-1,-1), 7*mm), ("RIGHTPADDING", (0,0), (-1,-1), 7*mm), ("TOPPADDING", (0,0), (-1,-1), 5*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 5*mm)]))
    story += [callout, Spacer(1, 6*mm)]
    cards = []
    for k in [3,5,10]:
        hb = summary_row(payload, k, "HB-TPM")["swd_mean"]
        vae = summary_row(payload, k, "Source-adapted VAE")["swd_mean"]
        reduction = 100*(vae-hb)/vae
        cards.append(Paragraph(f"<font name='HeitiBold' size='18'>{reduction:.1f}%</font><br/>K={k} SWD 降低<br/>{paired_wins(payload,k)}/30 配对胜", styles["card"]))
    card_table = Table([cards], colWidths=[58*mm]*3)
    card_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#EDF3FF")), ("BOX", (0,0), (-1,-1), 0.7, colors.HexColor("#B8CBF5")), ("INNERGRID", (0,0), (-1,-1), 0.7, colors.white), ("TOPPADDING", (0,0), (-1,-1), 5*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 5*mm)]))
    story += [card_table, Spacer(1, 7*mm), Paragraph("研究问题与方法设计", styles["h1"])]
    bullets = [
        "Source 阶段观测有序的 (t,x)，估计轨迹族的系数均值、方差与噪声尺度；target 阶段只接收 K 个无序观测点。",
        "实验中 oracle 使用私有 Fourier 表示，而 HB-TPM 使用通用 degree-9 Bernstein basis，避免 estimator 直接获得生成器表示。",
        "方法优势来自 source ordering 携带的可迁移结构，以及层级 shrinkage 在 K 很小时对自由度的限制。",
    ]
    for i, item in enumerate(bullets, 1): story.append(Paragraph(f"<font name='HeitiBold'>{i}.</font> {item}", styles["body"]))
    story += [Spacer(1, 3*mm), Paragraph("适用范围", styles["h1"]), Paragraph("HB-TPM 面向天然具有时间、伪时间、剂量、病程或视频帧序的数据。这里的 source ordering 是 pooled-density VAE baseline 没有使用的监督信号；因此下一阶段需要加入同样接收 ordering 的 conditional/meta-VAE，形成同等监督下的比较。", styles["body"]), PageBreak()]

    story += [Paragraph("1. 方法流程", styles["h1"]), RLImage(str(METHOD_FLOW_FIG), width=174*mm, height=98.2*mm), Spacer(1, 3*mm)]
    story += [Paragraph("模型", styles["h2"]), Paragraph("固定一个与 oracle 不同的通用平滑 basis Phi(t)。对 source task j：gamma_j(t)=Phi(t)W_j，且 W_j ~ N(W0,Lambda)。有序 source 的 (t,x) 用于估计 W0、Lambda 和噪声尺度 sigma。target 只有无序点 x_i，时间索引 t_i 是 latent variable。", styles["body"])]
    eq = Table([[Paragraph("t_i ← arg min_t ||x_i - Phi(t)W||^2", styles["body"]), Paragraph("W ← arg min_W  sigma^-2 sum_i||x_i-Phi(t_i)W||^2 + ||W-W0||^2_{Lambda^-1}", styles["body"])]], colWidths=[65*mm, 109*mm])
    eq.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#F4F7FB")),("BOX",(0,0),(-1,-1),0.6,colors.HexColor("#CBD5E1")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),4*mm),("RIGHTPADDING",(0,0),(-1,-1),4*mm),("TOPPADDING",(0,0),(-1,-1),3*mm),("BOTTOMPADDING",(0,0),(-1,-1),3*mm)]))
    story += [eq, Spacer(1, 3*mm), Paragraph("两个更新交替到 latent index 稳定。生成时沿拟合曲线取样，再加入 source-calibrated 噪声。注意：实验 ablation 显示法向噪声不是主要增益；主要增益已发生在曲线后验本身。", styles["body"]), PageBreak()]

    story += [Paragraph("2. Held-out 可视化示例", styles["h1"]), Paragraph("四个面板使用同一真实曲线 PCA 投影、相同坐标范围和完整 8D 数组。黑色虚线都是真实曲线。VAE 本身没有唯一显式轨迹，因此 C 面板只画生成点；若增加曲线，则需要额外的 post-hoc curve estimator。", styles["body"]), RLImage(str(VISUAL_FIG), width=174*mm, height=47.1*mm), Spacer(1, 4*mm)]
    story += [Paragraph("如何阅读四个面板", styles["h2"]), Paragraph("Naive TPM 主要连接 K 个 shot 所覆盖的局部范围；VAE 点云覆盖较宽，但不提供稳定的一维顺序；HB-TPM 利用 source prior 补全未观察轨迹段。该示例用于解释方法行为，统计结论来自 30 个 held-out tasks 的配对指标。", styles["body"]), PageBreak()]

    story += [Paragraph("3. Benchmark 结果", styles["h1"]), RLImage(str(BENCHMARK_FIG), width=174*mm, height=70.7*mm), Spacer(1, 2*mm)]
    table_data = [["K", "HB-TPM SWD", "Source-VAE SWD", "相对降低", "配对胜场"]]
    for k in [3,5,10]:
        hb = summary_row(payload,k,"HB-TPM"); vae = summary_row(payload,k,"Source-adapted VAE")
        reduction = 100*(vae["swd_mean"]-hb["swd_mean"])/vae["swd_mean"]
        table_data.append([str(k), f"{hb['swd_mean']:.4f} ± {hb['swd_se']:.4f}", f"{vae['swd_mean']:.4f} ± {vae['swd_se']:.4f}", f"{reduction:.1f}%", f"{paired_wins(payload,k)}/30"])
    tab = Table(table_data, colWidths=[16*mm,45*mm,45*mm,32*mm,30*mm])
    tab.setStyle(TableStyle([("FONTNAME",(0,0),(-1,-1),"Heiti"),("FONTNAME",(0,0),(-1,0),"HeitiBold"),("FONTSIZE",(0,0),(-1,-1),8.5),("BACKGROUND",(0,0),(-1,0),colors.HexColor(NAVY)),("TEXTCOLOR",(0,0),(-1,0),colors.white),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F4F7FB")]),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#CBD5E1")),("ALIGN",(0,0),(-1,-1),"CENTER"),("TOPPADDING",(0,0),(-1,-1),2.5*mm),("BOTTOMPADDING",(0,0),(-1,-1),2.5*mm)]))
    story += [tab, Spacer(1, 4*mm), Paragraph("Ablation 与边界", styles["h2"]), Paragraph("去掉有效 shrinkage 后，K=3/5/10 的 curve error 为 0.3047/0.2957/0.1623；完整 HB-TPM 为 0.2588/0.1717/0.0845。Gaussian negative control 中，正确指定的 Gaussian estimator 在 82/90 次比较中胜 naive TPM。这说明方法只在结构假设匹配时有优势。", styles["body"]), Paragraph("公平性提醒：source-adapted VAE 使用同样的 pooled source samples，但没有 source ordering；因此这里测到的是 ordering-aware structured transfer 相对 pooled-density transfer 的价值，不是同等监督下所有 VAE 的上界。", styles["body"]), PageBreak()]

    story += [Paragraph("4. 代码地图、复现与最终结论", styles["h1"])]
    code_rows = [
        ["文件", "关键位置", "作用"],
        ["core.py", "TrajectoryOracle", "只负责 oracle 模拟；私有 basis 不供 estimator 使用"],
        ["core.py", "learn_hierarchical_prior", "由 ordered source 估计 W0、Lambda、sigma"],
        ["core.py", "fit_hb_tpm", "latent-index / coefficient MAP 交替更新"],
        ["core.py", "sample_hb_tpm", "从拟合轨迹生成样本"],
        ["core.py", "NumpyVAE", "target-only 与 source-adapted VAE baseline"],
        ["run_experiment.py", "main", "30×3 paired benchmark 与 Gaussian control"],
        ["make_final_artifacts.py", "main", "共享 PCA 图、aggregate 图和本 PDF"],
    ]
    code_tab = Table(code_rows, colWidths=[43*mm,48*mm,83*mm])
    code_tab.setStyle(TableStyle([("FONTNAME",(0,0),(-1,-1),"Heiti"),("FONTNAME",(0,0),(-1,0),"HeitiBold"),("FONTSIZE",(0,0),(-1,-1),8),("BACKGROUND",(0,0),(-1,0),colors.HexColor(NAVY)),("TEXTCOLOR",(0,0),(-1,0),colors.white),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F4F7FB")]),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#CBD5E1")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),2.5*mm),("RIGHTPADDING",(0,0),(-1,-1),2.5*mm),("TOPPADDING",(0,0),(-1,-1),2.0*mm),("BOTTOMPADDING",(0,0),(-1,-1),2.0*mm)]))
    story += [code_tab, Spacer(1, 5*mm), Paragraph("复现命令", styles["h2"]), Paragraph("python hb_tpm_trajectory_model/run_experiment.py<br/>python hb_tpm_trajectory_model/make_final_artifacts.py", styles["code"]), Spacer(1, 3*mm), Paragraph("结论", styles["h2"]), Paragraph("当 source ordering 是真实可获得的领域信号时，低维轨迹族后验在 extreme few-shot 下比忽略 ordering 的 pooled-density model 更样本有效、更可审计。最重要的优势起源是信息结构，而不是生成更多点或法向 tube。若真实任务没有可靠 ordering 或同族 source，则应使用经过验证的分布模型。", styles["body"]), Paragraph("后续评估包括：同样接收 (t,x) ordering 的 conditional/meta-VAE、source-family mismatch sweep、不同 basis / ambient dimension / noise 的稳健性，以及真实有序数据。", styles["body"])]
    doc.build(story)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    payload = json.loads(RESULT_JSON.read_text(encoding="utf-8"))
    make_method_flow_figure()
    make_method_figure()
    make_visual_figure(payload)
    make_benchmark_figure(payload)
    make_report(payload)
    print(json.dumps({"method_flow": str(METHOD_FLOW_FIG), "method_code_map": str(METHOD_FIG), "visual": str(VISUAL_FIG), "benchmark": str(BENCHMARK_FIG), "report": str(REPORT_PDF)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
