# AGENTS.md

Scope: this file governs the photon-counting FCS proposal project.

## Visual Style

Use a clean academic report style with generous whitespace, readable tables,
and figure colors inspired by the two preferred benchmark palettes from the
FlowDistribution/SFD figures: a clean pastel categorical palette on white, plus
a secondary baseline/accent palette with deep teal and deep periwinkle.

Preferred categorical palette, in the visual order used by the benchmark bars:

| Name | Hex | Use |
| --- | --- | --- |
| Mint | `#9ED9C8` | first method/category, positive or primary flow |
| Ochre | `#D7BA68` | classical baseline or calibration layer |
| Sky | `#8FC3DA` | observation/data layer |
| Lavender | `#B7A4D8` | diagnostic, survival, SFD or future layer |
| Apricot | `#F7C97C` | likelihood, inference or estimator layer |
| Pear | `#C7D676` | model checking or validation |
| Dusty rose | `#CDA4A0` | caution, industry or adjacent evidence |
| Coral | `#F48A83` | key result, selected estimator or highlight |

Secondary deep accents:

| Name | Hex | Use |
| --- | --- | --- |
| Deep teal | `#3F8F73` | strong baseline, reference, residual bucket |
| Deep periwinkle | `#6673B7` | contrast baseline or uncertainty |
| Ink | `#111827` | text and axes |

Rules:

- Prefer pastel fills with darker related outlines, not saturated blocks.
- Keep charts on a white background with light gray gridlines.
- Use warm-white only as a very subtle figure panel tint, never as the dominant
  page color.
- Use the palette consistently across report figures, tables, callout boxes,
  and generated plots.
- For benchmark-like charts, map method bars left-to-right as Mint, Ochre, Sky,
  Lavender, Apricot, Pear, Dusty rose, Coral. Use Deep teal and Deep periwinkle
  only for reference/baseline/accent curves.
- Avoid dense text inside figures. If a figure repeats a table, remove it or
  replace it with a short callout.
- Use figures only when they clarify workflow, simulation, or model structure.
  Dense industry maps should usually be tables instead.

## PDF Report Checks

For every substantial PDF update:

1. Recompile the LaTeX source twice.
2. Render the title/ToC, edited pages, major figure pages, and references to PNG.
3. Visually check for overlapping text, cramped tables, excessive blank space,
   unreadable figure labels, and inconsistent colors.
4. Copy the final PDF to `outputs/pdf/fcs_complete_lit_review_qian.pdf`.

## Simulation Contract

For photon-counting simulations in this project:

1. Keep the hierarchy explicit: molecular dynamics -> optical profile ->
   conditional photon process -> instrument marks -> derived summaries.
2. Separate simulation-only truth from estimator-visible data. Molecule IDs and
   latent positions may be exported for validation, but analysis code must not
   silently use them.
3. Store a resolved settings file, RNG seed, units, schema version, and data
   dictionary with every run.
4. Use `um`, `s`, `cps`/`kcps`, and `ns` consistently. State the Gaussian PSF
   convention because width conventions differ across FCS literature.
5. Treat one molecule as an algorithmic oracle and multiple molecules as the
   standard stationary-FCS scenario. Never equate single-molecule sensitivity
   with exactly one molecule in the complete sample.
6. Before Monte Carlo sweeps, check count conservation, sorted event times,
   periodic-boundary support, expected versus realized photon budget, and
   sensitivity to the Brownian time step.
7. Label piecewise-constant conditional-PPP simulation honestly; do not call it
   exact for a continuous Brownian path unless Brownian-bridge/thinning error is
   controlled.
8. Keep clean physics, photophysics, and artifact mechanisms as separate
   settings so each source of model mismatch can be switched on deliberately.

## Simulation Deliverables

A teaching-quality simulation addition should include:

- a reusable Python module and command-line runner;
- JSON settings for single-molecule, multi-molecule, and artifact scenarios;
- an executed Jupyter notebook;
- latent trajectory truth, photon-event records, binned intensity, FCS, TCSPC,
  resolved settings, summary metadata, and a field-level data dictionary;
- deterministic smoke tests and visually inspected figures.
