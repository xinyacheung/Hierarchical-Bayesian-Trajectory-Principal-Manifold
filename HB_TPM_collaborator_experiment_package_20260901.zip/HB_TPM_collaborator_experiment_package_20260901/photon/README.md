# Observation-aware photon HB-TPM

## Implemented P0

The packaged model represents the smooth diffusion trajectory as

\[
\log D_j(t)=(1-t/T)w_{j,0}+(t/T)w_{j,1},
\qquad w_j\sim N(w_0,\Lambda).
\]

Source records are first fitted using the photon event quasi-likelihood. Their
coefficient estimates and Laplace covariances define a deconvolved empirical
Gaussian prior. A sparse target is then fitted directly by

\[
\widehat w_c=\arg\max_w\left\{
\ell_{\rm event}(w;\{T_i\})
-\tfrac12(w-w_0)^\top\Lambda^{-1}(w-w_0)
\right\}.
\]

Source and target estimator APIs accept ordered `event_time_s` arrays only.
True `D(t)`, positions, molecule identities and conditional photon rates are
stored separately and joined only after fitting.

## Verified smoke

- 3/3 deterministic unit tests passed；
- 6 source records and 4 sparse target records；
- all simulation invariants passed；
- both methods had 100% fit success；
- mean relative curve RMSE: target-only `0.362`, OA-HB-TPM `0.145`；
- endpoint coverage: target-only `1.000`, OA-HB-TPM `0.875`。

This is a promising engineering smoke, not an efficacy result. The raw
deconvolved source covariance had one negative eigenvalue and was regularized;
the pilot must audit sensitivity to the variance floor and shrinkage.

## Run

```bash
python -m unittest photon/tests/test_observation_aware_hb_tpm.py

bash photon/scripts/run_gate.sh smoke
bash photon/scripts/run_gate.sh pilot
bash photon/scripts/run_gate.sh final
```

Do not start `final` until the unit, smoke, Brownian-step halving and pilot gates
have been signed off in `GATE_SIGNOFF.md`.

## CPU execution

The current finite-state event likelihood is SciPy/CPU code. Parallelize final
Monte Carlo over independent records or independent configurations. GPUs are
not expected to accelerate the current implementation without a JAX/PyTorch
rewrite.

