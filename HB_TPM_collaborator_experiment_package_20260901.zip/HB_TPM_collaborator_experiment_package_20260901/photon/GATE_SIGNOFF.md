# Photon gate sign-off

## Unit gate

- [x] `test_finite_difference_hessian_matches_quadratic`
- [x] `test_empirical_prior_deconvolves_measurement_covariance`
- [x] `test_hierarchical_fit_uses_only_events_and_moves_toward_prior`
- Reviewer/date: Codex automated run, 2026-08-25

## Smoke gate

- [x] 6 source / 4 target run completed
- [x] count conservation and simulator invariants passed
- [x] estimator truth-use flag false for every fit
- [x] output manifest and data dictionary written
- [ ] independent human inspection of code and figure

## Brownian-step halving gate

- [ ] same trajectory family and paired seeds at `dt` and `dt/2`
- [ ] photon budget and primary estimates stable within prespecified tolerance
- [ ] tolerance and decision recorded before comparison

## Pilot gate

- [ ] 20 source / 20 target completed
- [ ] prior variance-floor sensitivity checked
- [ ] failure/boundary/truncation rates acceptable
- [ ] methods, metrics, settings and seeds frozen
- [ ] no post-hoc target-truth tuning

## Final gate

- [ ] final config hash recorded
- [ ] 40 source / 100 paired targets completed
- [ ] negative-control suite completed
- [ ] held-out likelihood and predictive FCS completed
- [ ] results independently reproduced

