# Cardiac sparse-cycle reconstruction

## What is runnable

This directory contains both experiment settings. Keep their claims separate.

1. `run_oracle_contour_baseline.py` receives manual masks at the declared sparse
   frames. It isolates trajectory recovery and is **not** end-to-end imaging.
2. `train_observation_aware.py` implements the intended PyTorch pipeline:

```text
K sparse raw ultrasound frames
    -> shared 2-D CNN and heteroskedastic latent observations
    -> Gaussian posterior over periodic Fourier coefficients
    -> full-cycle latent trajectory
    -> full-cycle LV masks + posterior predictive uncertainty
```

The deep model's `forward` method has no full image-sequence argument. The
runner gathers the K observed images first, normalizes them using those K images
only, and gives the model the observed images/times plus a harmless full-cycle
time grid. Target hidden images and all target masks remain scoring-only.

## 1. Prepare and validate a private manifest

Create a CSV with one row per patient:

```csv
patient_id,image_sequence_path,mask_sequence_path,n_frames,frame_period_s,dataset,time_axis
patient0001,/private/TED/patient0001_images.nii.gz,/private/TED/patient0001_masks.nii.gz,32,0.033,TED,-1
```

Validate raw arrays:

```bash
python cardiac/scripts/validate_manifest.py \
  --manifest /private/manifests/ted_manifest.csv \
  --check-arrays
```

Standardize geometry for batching. Temporal standardization selects nearest raw
frames and never interpolates across time; spatial resizing is framewise. This
step does no intensity normalization:

```bash
python cardiac/scripts/prepare_standardized_sequences.py \
  --manifest /private/manifests/ted_manifest.csv \
  --output-dir /private/processed/ted_32x112 \
  --frames 32 --height 112 --width 112
```

Set `--frames` no larger than the shortest raw sequence. The script refuses
temporal upsampling because duplicated raw frames would make a nominal K-shot
experiment contain fewer than K distinct observations.

Omit `--mask-label` only for genuinely binary masks. If more than one nonzero
label is present, preprocessing stops and prints the available labels instead
of merging anatomical structures. Confirm the LV-cavity label from the dataset
codebook before continuing.

Use `/private/processed/ted_32x112/standardized_manifest.csv` below.

## 2. Freeze patient splits and sparse observations

```bash
python cardiac/scripts/make_sparse_splits.py \
  --manifest /private/processed/ted_32x112/standardized_manifest.csv \
  --config cardiac/configs/ted_sparse_cycle.json \
  --output-dir cardiac/outputs/splits_v1
```

Every method must consume the same `patient_splits.csv` and
`sparse_observations.csv`.

## 3. Run the oracle-contour mechanism baseline

```bash
python cardiac/scripts/run_oracle_contour_baseline.py \
  --manifest /private/processed/ted_32x112/standardized_manifest.csv \
  --splits cardiac/outputs/splits_v1/patient_splits.csv \
  --observations cardiac/outputs/splits_v1/sparse_observations.csv \
  --fold 0 \
  --output-dir cardiac/outputs/oracle_fourier_fold0
```

## 4. Smoke-test the end-to-end model locally

The automated test creates synthetic image sequences, trains one epoch, runs
posterior prediction for all six method switches, and checks provenance outputs:

```bash
python -m unittest cardiac/tests/test_deep_model_smoke.py -v
```

This is an engineering test only, not an efficacy result.

On an allocated GPU node, also run:

```bash
python cardiac/scripts/gpu_preflight.py --output gpu_preflight.json
```

It must identify CUDA and complete forward, posterior-sampling, and backward
gradient checks before submitting the array.

## 5. Run one real image-observation experiment

```bash
python cardiac/scripts/train_observation_aware.py \
  --config cardiac/configs/oa_hb_tpm_main.json \
  --manifest /private/processed/ted_32x112/standardized_manifest.csv \
  --splits cardiac/outputs/splits_v1/patient_splits.csv \
  --observations cardiac/outputs/splits_v1/sparse_observations.csv \
  --fold 0 --k 3 --strategy uniform \
  --method oa_hb_tpm_map \
  --output-dir cardiac/outputs/oa_fold0_k3_uniform
```

Implemented method switches:

- `oa_hb_tpm_map`: heteroskedastic observation likelihood and learned source
  coefficient prior; conjugate posterior mean equals the coefficient MAP;
- `target_only`: weak coefficient prior (no hierarchical trajectory shrinkage),
  while retaining the same source-trained image encoder/decoder;
- `source_mean`: source coefficient mean without target coefficient updating,
  while retaining observed-image phase alignment; its coefficient uncertainty
  is not trained and is therefore reported as unavailable rather than sampled;
- `hb_tpm_latent_mse`: Euclidean latent observation loss ablation;
- `oa_hb_tpm_no_phase_alignment`: phase-offset ablation;
- `oa_hb_tpm_isotropic_prior`: shared prior-variance ablation.

Do not describe `target_only` as a completely target-trained segmentation
network; it is the target-only **trajectory** baseline with the observation
model held comparable.

Each run writes a checkpoint, history, patient-level results, validation-only
trust-gate calibration, area-trajectory credible-interval coverage, frozen
visible inputs, environment, resolved config, hashes, and a run manifest.
Random and clustered frozen replicates are all evaluated within the job.

## 6. Submit the 25-job main grid on the 4090 cluster

Activate the collaborator's CUDA PyTorch environment first. `ENTRYPOINT` is no
longer external: the SLURM script defaults to the implementation in this package.

```bash
MANIFEST=/private/processed/ted_32x112/standardized_manifest.csv \
SPLITS=$PWD/cardiac/outputs/splits_v1/patient_splits.csv \
OBSERVATIONS=$PWD/cardiac/outputs/splits_v1/sparse_observations.csv \
RUN_ROOT=$PWD/cardiac/outputs/oa_main \
sbatch --array=0-24%8 cardiac/slurm_cardiac_array.sbatch
```

Each fold/K model is trained once with a reproducible mixture of uniform,
random, and clustered source observations, then evaluates all three frozen test
strategies. This avoids training the same fold/K model three times. For an
ablation, set `METHOD`, for example
`METHOD=oa_hb_tpm_no_phase_alignment`; method-specific subdirectories prevent
collisions. The runner refuses accidental overwrite by default.

## Current scientific boundary

The architecture and training/evaluation pipeline are implemented and locally
tested. Real TED effectiveness, hyperparameter adequacy, calibration, all
classical baselines, and external EchoNet/TED/ACDC validation remain experiments
to run. No synthetic smoke number should enter the manuscript as a result.
