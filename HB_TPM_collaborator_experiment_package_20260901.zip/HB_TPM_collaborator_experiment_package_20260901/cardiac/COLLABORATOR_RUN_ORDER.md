# Run order for the 4090 collaborator

The answer to “do I only run data preparation and the oracle-contour baseline?”
is **no**. Those are Phase A/B checks. The package now includes the intended
image-observation PyTorch model for Phase C/D.

## Phase 0 — environment and engineering gate

Create a CUDA-enabled PyTorch environment on the cluster, install
`requirements.txt`, then run from the package root:

```bash
python scripts/preflight.py
python -m unittest cardiac/tests/test_deep_model_smoke.py -v
python cardiac/scripts/gpu_preflight.py --output gpu_preflight.json
```

The last command must report a CUDA device on the allocated 4090 node and checks
one forward pass, posterior sampling, and backward gradients. Send back the
environment versions and full output if any command fails.

## Phase A — TED data only

1. Download TED from <https://humanheart-project.creatis.insa-lyon.fr/ted.html>.
2. Create and validate the patient manifest.
3. Inspect the annotation codebook and run
   `prepare_standardized_sequences.py`; pass the LV-cavity `--mask-label` for
   multiclass masks. Choose a target frame count no larger than the shortest
   sequence. The script refuses both merged labels and temporal upsampling.
4. Generate the frozen patient splits and sparse observation table.
5. Send back the two CSVs plus a shape/fold summary; do not send medical data.

Do not start with EchoNet or ACDC. TED is the internal full-cycle gate.

## Phase B — oracle-contour mechanism check

Run `run_oracle_contour_baseline.py` for folds 0–4. This verifies sparse-index
handling, periodic trajectory reconstruction, hidden-frame metrics, and output
provenance. It cannot support an end-to-end image claim.

## Phase C — primary image-observation run

Run the 25-job grid with `METHOD=oa_hb_tpm_map`:

```bash
MANIFEST=/private/processed/ted_32x112/standardized_manifest.csv \
SPLITS=$PWD/cardiac/outputs/splits_v1/patient_splits.csv \
OBSERVATIONS=$PWD/cardiac/outputs/splits_v1/sparse_observations.csv \
RUN_ROOT=$PWD/cardiac/outputs/oa_main \
METHOD=oa_hb_tpm_map \
sbatch --array=0-24%8 cardiac/slurm_cardiac_array.sbatch
```

There are 5 folds × 5 shot budgets. Each trained model evaluates uniform,
random, and clustered test observations—including all frozen replicates—so the
three test strategies do not trigger redundant training jobs.

First submit one job and inspect `history.csv`, `patient_results.csv`, GPU memory,
runtime, and `run_manifest.json`. Submit the full grid only after that job passes.

## Phase D — minimum method comparisons

Reuse the same `RUN_ROOT`; the SLURM script creates a method-specific
subdirectory for each of:

1. `target_only` — weak trajectory prior;
2. `source_mean` — no target coefficient update;
3. `hb_tpm_latent_mse` — non-observation-aware loss ablation;
4. `oa_hb_tpm_no_phase_alignment`;
5. `oa_hb_tpm_isotropic_prior`.

The full paper benchmark still requires the classical interpolation, GP,
state-space, and statistical-shape baselines listed in `EXPERIMENT_DESIGN.md`.

## Phase E — only after TED succeeds

- EchoNet-Dynamic (<https://echonet.github.io/dynamic/>): encoder/video
  pretraining and ED/ES auxiliary supervision; every user registers separately;
  it does not provide full-cycle manual contours.
- ACDC/CETUS challenge resources
  (<https://humanheart-project.creatis.insa-lyon.fr/challenges.html>): endpoint or
  cross-modality robustness, not TED-equivalent full-cycle truth.

## Return package

After the main and ablation arrays finish, aggregate without treating frames as
independent samples:

```bash
python cardiac/scripts/aggregate_gpu_runs.py \
  --input-root cardiac/outputs/oa_main \
  --output-dir cardiac/outputs/aggregate_v1
```

Return all run directories, including configs, environment, logs, checkpoints,
patient-level CSVs, observed-input tables, and run manifests. Do not return only
screenshots or aggregated means, and do not upload the underlying medical data.
