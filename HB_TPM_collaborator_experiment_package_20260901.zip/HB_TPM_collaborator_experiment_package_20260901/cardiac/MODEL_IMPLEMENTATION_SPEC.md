# Cardiac observation-aware HB-TPM: implemented contract

Implementation: `src/observation_aware_cardiac.py`  
Runner: `scripts/train_observation_aware.py`

## Estimator-facing tensor contract

- `observed_frames`: `(B,K,1,H,W)`; already gathered from frozen indices;
- `observed_times`: `(B,K)` normalized to `[0,1)`;
- `full_times`: `(B,T)`; a design grid containing no image information;
- output mask logits: `(B,T,1,H,W)`;
- coefficient posterior mean/covariance: `(B,P,L)` and `(B,L,P,P)`;
- phase offset: `(B,)`;
- posterior mask samples: `(S,B,T,1,H,W)`.

There is deliberately no `(B,T,1,H,W)` image input to `forward`. This makes it
impossible for a hidden target image to reach the estimator accidentally.

## Implemented model

The shared CNN produces mean and log variance for each observed frame,

\[
q_\psi(z_{jk}\mid x_{jk})
=N\{m_{jk},\operatorname{diag}(r_{jk})\}.
\]

With periodic basis

\[
\Phi(\phi)=[1,\cos(2\pi\phi),\sin(2\pi\phi),\ldots]^\top,
\qquad W_j\sim N(W_0,\Lambda),
\]

the latent observation model is

\[
m_{jk}=\Phi(\phi_{jk}+\delta_j)^\top W_j+\epsilon_{jk},
\qquad \epsilon_{jk}\sim N(0,R_{jk}).
\]

The main model uses a learned full covariance over Fourier coefficients within
each latent coordinate; the named isotropic ablation uses one shared variance.
For each latent coordinate, the exact Gaussian coefficient posterior is

\[
\Sigma_j^{-1}=\Lambda^{-1}+\Phi_{j,\mathcal O}^\top
R_{j,\mathcal O}^{-1}\Phi_{j,\mathcal O},
\]

\[
\mu_j=\Sigma_j\{\Lambda^{-1}W_0+
\Phi_{j,\mathcal O}^\top R_{j,\mathcal O}^{-1}m_{j,\mathcal O}\}.
\]

Thus `oa_hb_tpm_map` uses `mu_j`, which is both the posterior mean and MAP in
this conjugate layer. Posterior coefficient samples are decoded to quantify
mask-level predictive variability and 95% LV-area trajectory coverage. Primary
Dice/HD95 predictions use the deterministic coefficient MAP rather than
silently substituting a Monte Carlo posterior mean.

The phase offset is a bounded circular shift inferred only from the observed
set. Monotone time warping is not enabled.

## Training losses

Source patients provide full-cycle mask supervision:

\[
\mathcal L=\mathcal L_{\rm BCE+Dice}
+\lambda_{\rm obs}\mathcal L_{\rm hetero}
+\lambda_{\rm KL}\operatorname{KL}\{q(W_j)\Vert p(W)\}
+\lambda_{\rm cyc}\mathcal L_{\rm cycle}
+\lambda_{\rm temp}\mathcal L_{\rm temporal}.
\]

At test time the estimator receives only K target images. Target masks and
hidden images are read by the evaluation layer for scoring but never passed to
the model.

## Implemented variants

- `target_only` (weak coefficient prior; shared source-trained observation model);
- `source_mean` (phase-aligned deterministic source mean; uncertainty unavailable);
- `hb_tpm_latent_mse`;
- `oa_hb_tpm_map`;
- `oa_hb_tpm_no_phase_alignment`;
- `oa_hb_tpm_isotropic_prior`.

## Trust gate

The runner calibrates a standardized latent observation-residual threshold at
the requested quantile using validation patients only. Target observations over
that threshold are marked `trust_gate_reject`; target labels do not calibrate
the gate. Family-shift stress experiments are still required to establish that
this diagnostic has useful power.

## Checkpoint and run provenance

Each run records fold, K, strategy, method, source/target patient hashes, config
hash, split/observation hashes, git commit when available, seed, environment,
best validation patient-level Dice, estimator-visible tensors, scoring-only
tensors, and SHA-256 hashes of primary outputs.

## Still required before a paper claim

- real TED 5-fold execution and hyperparameter selection without test leakage;
- classical image/shape baselines and fold-aware paired uncertainty intervals;
- real-data calibration of area-trajectory coverage;
- family-shift stress tests for the validation-calibrated trust gate;
- EchoNet encoder-pretraining and TED/ACDC external validations, reported as
  distinct dataset settings.
