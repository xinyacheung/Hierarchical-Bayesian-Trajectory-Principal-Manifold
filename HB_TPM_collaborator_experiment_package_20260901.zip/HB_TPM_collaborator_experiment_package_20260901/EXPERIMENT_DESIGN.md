# Frozen experiment design

## 1. Scientific claim

HB-TPM 的核心论点应被拆成三个可证伪问题：

1. related ordered source trajectories 是否能降低 sparse target trajectory 的估计误差？
2. observation-aware posterior 是否优于先估 latent point、再拟合 trajectory 的两阶段流程？
3. 当 target 不属于 source family 时，uncertainty/trust gate 是否能识别失败而不是盲目 shrink？

所有主实验必须分别回答这三个问题。

## 2. Cardiac primary experiment

### Task

对一个未见过的 TED 患者，仅公开完整周期中的 `K` 个超声帧，恢复所有未观测帧的 LV mask/contour、area trajectory 和 ED/ES timing。

两种 observation setting 必须分开报告：

- **Oracle-contour setting**：输入稀疏帧的人工 masks，用于隔离 trajectory recovery 本身；
- **Image-observation setting**：输入稀疏 ultrasound frames，由模型同时处理图像噪声和 trajectory uncertainty。

Oracle-contour 结果不能被描述为端到端临床性能。

### Split

- 5-fold patient-level cross-validation；
- 固定 seed `20260825`；
- fold 内 target patient 的 hidden frames 不得用于 normalization、early stopping 或选择超参数；
- validation patients 与 test patients 完全分离；
- 每个 patient、`K` 和 strategy 使用预生成的 sparse index JSON，所有方法共享。
- source training 在三种 observation pattern 间做固定 seed 的 mixture；同一个 fold/K checkpoint 评估全部三种 test strategy，避免重复训练和 test-specific tuning。

### Sparse-frame budgets

`K = {2, 3, 5, 7, 10}`。

Sampling strategies：

1. `uniform`：近似均匀覆盖完整周期；
2. `random`：固定 seed 的无放回随机采样，5 次重复；
3. `clustered`：观察集中在周期中的一个短窗口，用于测试 coverage failure。

禁止根据 ED/ES 标签选择测试帧，除非该设置明确命名为 `ed_es_oracle` 并只作为上界。

### Model

周期轨迹使用 Fourier basis，而不是开放端点 Bernstein curve：

\[
s_j(\phi)=W_j^\top[1,\cos(2\pi\phi),\sin(2\pi\phi),\ldots]^\top,
\qquad W_j\sim N(W_0,\Lambda).
\]

目标患者使用 image/segmentation observation likelihood：

\[
\widehat W_c,\widehat\delta_c
=\arg\max_{W,\delta}
\sum_{k\in\mathcal O_c}
\log p_\theta\{x_{ck}\mid s_W(\phi_{ck}+\delta)\}
-\tfrac12\|W-W_0\|_{\Lambda^{-1}}^2.
\]

`delta` 是 circular phase offset；monotone time warping 是独立 ablation，不应默认开启。

### Baselines

- nearest/linear/cubic temporal interpolation；
- periodic Fourier interpolation；
- PCA/statistical shape model；
- GP trajectory；
- Kalman/state-space smoother；
- target-only periodic TPM；
- source-mean trajectory；
- pretrained autoencoder without hierarchy；
- TED temporal-consistency post-processing；
- observation-aware HB-TPM。

### Metrics

Primary：hidden-frame Dice、HD95、LV area-curve relative RMSE。

Secondary：ED/ES timing error、EF/area-change error、cycle-closure error、temporal acceleration/jerk、LV-area trajectory 95% coverage、validation-calibrated rejection rate、runtime。像素级 binary-mask coverage 只有在另行冻结统计定义后才能报告。

统计单元为 patient。报告 fold-aware patient bootstrap CI 和 paired differences；frame 只用于形成患者内指标。

### Ablations

- no source prior；
- isotropic vs coefficient-specific covariance；
- ordered vs shuffled source frames；
- Fourier order；
- no phase alignment；
- no observation uncertainty；
- Euclidean latent loss vs observation likelihood；
- source prior learned from TED vs EchoNet-pretrained representation。

## 3. Photon scientific experiment

### Clean family

\[
\log D_j(t)=(1-t/T)w_{j,0}+(t/T)w_{j,1},
\qquad w_j\sim N(w_0,\Lambda).
\]

Source 和 target estimator 均只能接收 `event_time_s` 与校准的 observation parameters。模拟 truth 在所有 estimates 固定后才合并评分。

### Methods

- target-only event QMLE；
- local W-LSE；
- source mean；
- two-stage empirical Bayes；
- direct observation-aware HB-TPM MAP；
- optional full Bayesian state-space model。

### Target information sweep

使用相同 truth trajectory，改变 target molecular brightness 或 acquisition duration，得到约 100、250、500、1000 detected photons 的 paired records。

### Primary metrics

- duration-integrated relative curve RMSE；
- endpoint/log-contrast RMSE；
- 95% credible-band coverage；
- failure/boundary/truncation rate；
- runtime。

### Negative controls

每个机制使用独立 settings，不得混进 clean baseline：

- step/oscillatory diffusion；
- blinking；
- bleaching；
- occupancy drift；
- PSF width error；
- source-target coefficient mean/covariance shift。

## 4. Decision rule for the manuscript

- 如果 cardiac 在 TED 的 patient-level primary metrics 上稳定优于 target-only 和 periodic baselines，放入当前 HB-TPM 主文。
- 如果 photon final 同时改善 RMSE、保持合理 coverage，并在 family shift 下正确拒绝，则作为第二应用；否则只放 Discussion 或另写 companion paper。
- 任何只有 smoke 或 post-hoc tuned 的结果不得出现在摘要、结论或主结果表。
