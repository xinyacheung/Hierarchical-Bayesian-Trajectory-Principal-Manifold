# Result and provenance contract

Every run directory must contain:

```text
config_resolved.json
environment.json
run_manifest.json
patient_or_record_results.csv
method_summary.csv
history.csv              # cardiac only
trust_gate_calibration.csv # cardiac only; validation patients only
logs/
figures/
checkpoints/              # cardiac only
observed_inputs/          # IDs/indices or photon arrivals
simulation_truth/         # photon simulations only; never estimator input
```

## Required manifest fields

- `run_id`, UTC timestamp and git commit；
- dataset and dataset version；
- patient/record split hash；
- resolved configuration hash；
- RNG seeds；
- Python/library/CUDA versions；
- hardware；
- estimator-visible fields；
- hidden/truth-only fields；
- success/failure counts；
- output-file hashes。

## No-overwrite policy

- smoke、pilot 和 final 使用不同输出目录；
- final 目录已存在时 runner 必须拒绝，除非显式提供 `--overwrite`；
- 修改 estimator 或 metric 后必须使用新的 `run_id`；
- 不允许手工修改 `method_summary.csv`。

## Statistical unit

- Cardiac：patient；
- Photon：independent simulated/experimental record；
- windows 和 frames 不是独立 biological replicates。

For cardiac method comparisons, run `cardiac/scripts/aggregate_gpu_runs.py`.
Its bootstrap resamples patients after matching method/reference results on
patient, fold, K, strategy, and replicate; it must not bootstrap frames.

## Figure policy

每张论文图必须在 `FIGURE_PROVENANCE.csv` 中登记：figure label、script、input result directory、config hash、seed set、output file 和人工处理说明。
