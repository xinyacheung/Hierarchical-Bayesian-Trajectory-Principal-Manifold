# Data access and dataset roles

## EchoNet-Dynamic

Official page: <https://echonet.github.io/dynamic/>

- 10,030 apical-four-chamber echocardiography videos；
- includes EF, EDV, ESV and expert LV tracings at two time points: end-diastole and end-systole；
- use it for video encoder/motion-prior pretraining and ED/ES auxiliary supervision；
- do not claim full-cycle manual contours；
- personal, non-commercial research use；each user must register separately；do not redistribute the dataset or download link。

## TED: Temporal Echocardiography Dataset

Official page: <https://humanheart-project.creatis.insa-lyon.fr/ted.html>

- 98 fully annotated full-cycle A4C sequences derived from CAMUS；
- public access without login according to the project page；
- primary dataset for hidden-frame full-cycle reconstruction and temporal-consistency evaluation。

## Human Heart Project challenges

Official page: <https://humanheart-project.creatis.insa-lyon.fr/challenges.html>

- CETUS: 45-patient 3D ultrasound ED/ES segmentation challenge；
- ACDC: 150-patient 3D cine-MRI dataset, five diagnostic groups, expert ED/ES references；
- ACDC/CETUS are endpoint or cross-modality validations, not full-cycle manual-contour truth。

## Local data layout

The package never contains medical data. Create a private manifest with one row per patient:

```csv
patient_id,image_sequence_path,mask_sequence_path,n_frames,frame_period_s,dataset,time_axis
patient0001,/private/TED/patient0001_images.nii.gz,/private/TED/patient0001_masks.nii.gz,32,0.033,TED,-1
```

Supported baseline array layouts are `(T,H,W)` or `(T,1,H,W)`. NIfTI and NumPy `.npy/.npz` are supported by the package baseline. Verify axis order visually before a large run.

Do not commit manifests containing identifying metadata, credentials, signed URLs or redistributed dataset paths.
