# HB-TPM collaborator experiment package

版本：2026-08-25

这份目录可以直接发给负责计算实验的合作者。它包含两条相互关联、但应分别验证的实验线：

1. **Sparse-frame cardiac-cycle reconstruction**：从少量目标患者超声帧恢复完整心动周期；
2. **Observation-aware photon HB-TPM**：从 source photon records 学习动力学轨迹先验，再从 sparse target photon arrivals 推断时间变化扩散轨迹。

当前 manuscript 放在 `manuscript/`。photon P0 已通过 3 个确定性单元测试和一次 6-source/4-target smoke；cardiac 部分提供冻结实验协议、数据契约、patient-level split 生成器、周期 contour baseline 和 SLURM 模板，深度 observation-aware 模型仍是明确标注的实现任务。

## 建议分工

- GPU/4090：cardiac encoder、segmentation backbone、periodic trajectory model、跨数据集迁移。
- CPU 多进程：photon likelihood、Brownian simulation、paired Monte Carlo、coverage 与 failure analysis。
- 论文负责人：逐图逐表 provenance、结果解释、manuscript 更新和投稿前 QA。

## 快速开始

```bash
unzip HB_TPM_experiment_package_20260825.zip
cd HB_TPM_experiment_package_20260825
python scripts/preflight.py
```

然后阅读：

1. `TODO.md`
2. `EXPERIMENT_DESIGN.md`
3. `DATA_ACCESS.md`
4. `RESULT_CONTRACT.md`
5. `MANUSCRIPT_HANDOFF.md`
6. `cardiac/README.md`
7. `photon/README.md`

## 三条不可违反的规则

1. 数据划分以 patient/record 为单位，禁止 frame-level leakage。
2. 模拟真值、未观测 cardiac frames 和隐藏 masks 只能用于最终评分，不能传给 estimator。
3. smoke/pilot 结果不得写成 final efficacy claim；只有冻结配置后的 paired final 才能进入主结果表。

## 当前状态

| 模块 | 状态 | 是否可写入论文结果 |
| --- | --- | --- |
| 当前 manuscript | 可阅读、尚未冻结 | 否，需完成 provenance audit |
| Photon unit tests | 3/3 通过 | 只能作为工程检查 |
| Photon 6-source/4-target smoke | 运行成功 | 否，样本量太小 |
| TED patient split 与 sparse-mask generator | 已提供 | 生成后需人工核查 |
| Periodic contour baseline | 已提供 | 运行并核查后可作为 baseline |
| Cardiac observation-aware deep model | 实现规格已冻结 | 尚未实现 |
