# Cardiac sparse-cycle reconstruction

## Purpose

This directory freezes the experiment contract before model development. It
provides patient-level splits, shared sparse-frame masks, a runnable
oracle-contour periodic baseline, and a multi-GPU job template.

The oracle-contour baseline receives ground-truth masks only at the declared
observed frames. It is a controlled trajectory-recovery experiment, not an
end-to-end image-segmentation result.

## 1. Prepare a private manifest

Create a CSV with one row per patient:

```csv
patient_id,image_sequence_path,mask_sequence_path,n_frames,frame_period_s,dataset,time_axis
patient0001,/private/TED/patient0001_images.nii.gz,/private/TED/patient0001_masks.nii.gz,32,0.033,TED,-1
```

`time_axis` is the time dimension in the stored array. The scripts convert the
sequence internally to `(T,H,W)`.

Validate it:

```bash
python cardiac/scripts/validate_manifest.py \
  --manifest /private/manifests/ted_manifest.csv \
  --check-arrays
```

## 2. Freeze splits and observations

```bash
python cardiac/scripts/make_sparse_splits.py \
  --manifest /private/manifests/ted_manifest.csv \
  --config cardiac/configs/ted_sparse_cycle.json \
  --output-dir cardiac/outputs/splits_v1
```

All methods must consume the same `patient_splits.csv` and
`sparse_observations.csv`.

## 3. Run the trajectory sanity baseline

```bash
python cardiac/scripts/run_oracle_contour_baseline.py \
  --manifest /private/manifests/ted_manifest.csv \
  --splits cardiac/outputs/splits_v1/patient_splits.csv \
  --observations cardiac/outputs/splits_v1/sparse_observations.csv \
  --fold 0 \
  --output-dir cardiac/outputs/oracle_fourier_fold0
```

Repeat folds 0--4. This baseline uses periodic Fourier regression on signed
distance masks and scores hidden frames only.

## 4. Implement the GPU model

Follow `MODEL_IMPLEMENTATION_SPEC.md`. The cluster entry point must accept the
CLI contract shown in `slurm_cardiac_array.sbatch`. Set `ENTRYPOINT` to the
implemented training script before submission.

```bash
ENTRYPOINT=/path/to/train_observation_aware.py \
MANIFEST=/private/manifests/ted_manifest.csv \
SPLITS=$PWD/cardiac/outputs/splits_v1/patient_splits.csv \
OBSERVATIONS=$PWD/cardiac/outputs/splits_v1/sparse_observations.csv \
sbatch --array=0-74%8 cardiac/slurm_cardiac_array.sbatch
```

The 75 jobs correspond to 5 folds × 5 shot budgets × 3 observation strategies.
Random strategy replicates should be handled inside each job using the frozen
observation table.

