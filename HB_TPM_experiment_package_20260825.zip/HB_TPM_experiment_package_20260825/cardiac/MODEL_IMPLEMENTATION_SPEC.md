# Cardiac model implementation specification

## Required class

```python
class CardiacObservationAwareHBTPM(torch.nn.Module):
    def encode_frames(self, frames, observed_mask): ...
    def infer_phase(self, encoded, frame_times, observed_mask): ...
    def infer_trajectory_posterior(self, encoded, phases, observed_mask): ...
    def decode_masks(self, trajectory_samples): ...
    def forward(self, frames, frame_times, observed_mask): ...
```

## Tensor contract

- `frames`: `(B,T,1,H,W)`; hidden frames must be zeroed or omitted before model input；
- `frame_times`: `(B,T)` normalized to `[0,1)`；
- `observed_mask`: `(B,T)` Boolean；
- output mask logits: `(B,T,1,H,W)`；
- output trajectory coefficient mean/covariance and phase offset；
- optional posterior samples: `(S,B,T,L)`。

## Architecture

1. 2D frame encoder shared across time；
2. set/attention aggregator over observed frames only；
3. periodic Fourier trajectory head；
4. source empirical prior over trajectory coefficients；
5. target MAP or amortized posterior conditioned on observed frames；
6. segmentation decoder or contour decoder。

Do not use positional padding that reveals hidden target frames. Frame times are
allowed; hidden images and masks are not.

## Losses

Source training:

\[
\mathcal L_{\rm src}
=\mathcal L_{\rm seg}
+\lambda_{\rm cyc}\mathcal L_{\rm cycle}
+\lambda_{\rm temp}\mathcal L_{\rm temporal}.
\]

Target adaptation:

\[
\mathcal L_{\rm tgt}
=-\sum_{k\in\mathcal O}\log p_\theta(x_k\mid s_W(\phi_k))
+\tfrac12\|W-W_0\|_{\Lambda^{-1}}^2.
\]

Primary observation-aware loss should be segmentation-logit likelihood or a
heteroskedastic contour likelihood. Euclidean latent MSE is an ablation.

## Required variants

- `target_only`；
- `source_mean`；
- `hb_tpm_latent_mse`；
- `oa_hb_tpm_map`；
- `oa_hb_tpm_no_phase_alignment`；
- `oa_hb_tpm_isotropic_prior`。

## Required checkpoint metadata

- fold、K、strategy、replicate；
- source/target patient IDs hash；
- config hash、git commit、seed；
- encoder/pretraining source；
- best validation patient-level metric；
- exact estimator-visible tensors。

