# Manuscript handoff

## Included files

- `manuscript/hb_tpm_manuscript_preprint.pdf`
- `manuscript/hb_tpm_manuscript_arxiv.pdf`
- `manuscript/template.tex`
- `manuscript/template_arxiv.tex`
- `manuscript/references.bib`
- `manuscript/hb_tpm_trajectory_model.zip`

The manuscript currently lists Xin-Ya Zhang as the third author with:

- Center for Interdisciplinary Studies, Westlake University；
- `xinyazhang08@gmail.com`。

The four-panel Oracle / Naive TPM / Source-adapted VAE / HB-TPM recovery figure
and an implementation-level HB-TPM algorithm are already included.

## Known submission blockers

1. Some MNIST/CelebA smoothness and classification scripts contain preset or
   illustrative numeric series rather than a fully traceable benchmark run.
2. The spiral classifier visualization is geometric and should not be called a
   trained classifier comparison unless retrained and regenerated.
3. Current image experiments do not isolate the contribution of the new
   hierarchical ordered-source prior.
4. The Bayesian label needs posterior uncertainty, calibration/coverage and a
   functioning trust gate.
5. Unrun cardiac, large-scale visual and single-cell material must remain
   explicitly labeled as protocol/future work.

## Update order after collaborator results return

1. Freeze final result directories and hashes.
2. Complete `FIGURE_PROVENANCE.csv`.
3. Replace illustrative/hard-coded figures with executed outputs or remove
   their quantitative claims.
4. Add cardiac as the primary real dynamic application.
5. Add photon only if the final paired Monte Carlo passes RMSE, coverage and
   failure-mode gates.
6. Recompile both manuscripts twice and visually inspect all edited pages.

