# Execution TODO

## P0：收到 package 当天

- [ ] 运行 `python scripts/preflight.py`。
- [ ] 新建独立环境并记录 Python、CUDA、PyTorch、NumPy、SciPy 版本。
- [ ] 为 EchoNet-Dynamic 单独注册；不要转发数据或下载链接。
- [ ] 下载 TED，核实 98 个完整周期病例及逐帧 mask。
- [ ] 将本地路径写入自己的 `.env`；不要把数据路径和凭据提交进代码。
- [ ] 把当前 package 提交到单独 git branch，记录初始 commit hash。

## P1：cardiac 数据与基线门槛

- [ ] 建立 `cardiac_manifest.csv`，每位患者一行，路径指向完整 image/mask sequence。
- [ ] 运行 `cardiac/scripts/validate_manifest.py`。
- [ ] 生成冻结的 5-fold patient-level splits 和 sparse-frame masks。
- [ ] 手工检查每个 fold 的患者数、帧数、病理或 EF 分布。
- [ ] 跑 oracle-contour periodic baseline，确认 cycle closure 和 hidden-frame scoring 正常。
- [ ] 跑 linear/cubic/GP/PCA shape baselines。
- [ ] 确认 test hidden frames 不进入 early stopping、model selection 或 normalization fitting。

## P2：cardiac observation-aware 模型

- [ ] 实现 `MODEL_IMPLEMENTATION_SPEC.md` 中的 `CardiacObservationAwareHBTPM` 接口。
- [ ] 先做 TED 内部 5-fold，不引入 EchoNet domain shift。
- [ ] 实现 source-only prior、target-only periodic TPM、hierarchical MAP 三个可比较版本。
- [ ] 实现周期 basis 与 phase-offset/time-warp ablation。
- [ ] 加入 heteroskedastic observation likelihood 或 segmentation uncertainty。
- [ ] 加入 posterior sampling/Laplace approximation 与 95% coverage。
- [ ] 完成 `K={2,3,5,7,10}`、三种 sampling strategy、至少 5 个 fold。
- [ ] 生成患者级 paired results；禁止把 frame 当独立样本做显著性检验。

## P3：EchoNet 与 ACDC 外部验证

- [ ] 只把 EchoNet 当作大规模视频/encoder 预训练数据；不要声称具有全周期人工 contours。
- [ ] 对 EchoNet 的 ED/ES tracing 做 endpoint auxiliary loss。
- [ ] 比较 TED-only 与 EchoNet-pretrained→TED。
- [ ] ACDC 只做 ED/ES endpoint 或跨模态 robustness；不要用于逐帧 ground truth claim。
- [ ] 报告 domain shift 导致的失败率与 trust-gate rejection。

## P4：photon observation-aware gates

- [x] 3 个新增确定性单元测试通过。
- [x] 6-source/4-target smoke 运行成功，所有 simulation invariants 通过。
- [ ] 检查 source empirical covariance 的正则化敏感性。
- [ ] 跑相同 seed 的 Brownian-step halving gate。
- [ ] 跑 20-source/20-target pilot。
- [ ] 冻结 prior rule、bounds、state truncation、refinement grid、seeds 和 schema。
- [ ] 跑 40-source/100-target paired final。
- [ ] 加入 target-only event QMLE、W-LSE、source mean、two-stage EB 和 state-space baseline。
- [ ] 加入 step、oscillation、blinking、bleaching、occupancy drift、PSF mismatch 和 family shift。
- [ ] 报告 curve RMSE、log contrast、coverage、failure、runtime、held-out likelihood 和 predictive FCS。

## P5：进入 manuscript 前

- [ ] 每张图和每张表都有脚本、冻结配置、seed、原始 CSV 和 manifest。
- [ ] 删除或重跑 manuscript 中 hard-coded/illustrative 的 MNIST、CelebA、spiral 数值。
- [ ] 把未运行内容明确写为 protocol/future work。
- [ ] 主结果优先放 cardiac；photon 只有通过 final gate 后才能作为第二应用。
- [ ] LaTeX 编译两次，逐页渲染检查，核对作者和 affiliation。

