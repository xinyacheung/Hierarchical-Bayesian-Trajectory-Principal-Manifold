# TED Results Analysis and Diagnostic Report

## Executive conclusion

The delivered 98-patient experiment does not support the strongest frozen claims for the observation-aware MAP model. The latent-MSE HB-TPM is the strongest end-to-end method on the three primary outcomes: it ranks first in 15/15 Dice cells, 15/15 HD95 cells, and 14/15 area-RMSE cells. Its equal-cell global means are Dice 0.7532, HD95 9.406 px, and area RMSE 0.5646.

OA-HB-TPM MAP is nearly tied with its isotropic-prior and no-phase ablations, does not improve overall on source mean (MAP Dice 0.7481 versus source mean 0.7495), and shows poor nominal-95% area coverage (40.2%; latent-MSE 60.0%). The intervals below are descriptive uncertainty intervals for patient-paired mean differences, not post-hoc significance tests.

The trust gate is highly sensitive to observation geometry: OA-HB-TPM MAP rejects approximately 5.7% of uniform, 67.3% of random, and 87.9% of clustered observations. This supports a sampling-pattern sensitivity claim only; family-shift detection was not tested.

![Performance versus K](figures/performance_vs_k.png)

## Analysis population and methods

The statistical unit is the patient. The analysis first averaged the five random or clustered sampling replicates within each patient-method-K-strategy cell; uniform has one replicate. Global estimates then gave each of the five K values and three sampling strategies equal weight, preventing the five-replicate strategies from dominating uniform sampling.

All confidence intervals use 5,000 deterministic bootstrap draws (seed 20260825) with patients resampled independently within each held-out fold. Patient pairing is complete for every prespecified contrast. A confidence interval containing zero is labeled inconclusive. No clinical-importance threshold was prespecified, so this report makes no clinical-significance claim.

The three primary contrasts are OA-HB-TPM MAP minus target-only (source-prior contribution), OA-HB-TPM MAP minus latent-MSE HB-TPM (likelihood versus latent-MSE training), and OA-HB-TPM MAP minus source mean (value of patient-specific updating). Higher Dice is better; lower HD95 and area RMSE are better.

## Primary results

### Source-prior contribution: OA-HB-TPM MAP versus target-only

Hidden Dice: 0.0012 (95% CI 0.0005 to 0.0020; 0.17%; beneficial); Hidden HD95 (px): -0.044 (95% CI -0.081 to -0.003; -0.44%; beneficial); Area relative RMSE: -0.0059 (95% CI -0.0076 to -0.0040; -0.96%; beneficial).

The estimated effects are small relative to fold-to-fold heterogeneity. Interpret any interval excluding zero as evidence about this frozen experiment, not as a clinical effect.

### Observation-aware likelihood versus latent-MSE training

Hidden Dice: -0.0050 (95% CI -0.0101 to 0.0003; -0.67%; inconclusive); Hidden HD95 (px): 0.459 (95% CI 0.155 to 0.754; 4.88%; harmful); Area relative RMSE: 0.0364 (95% CI 0.0163 to 0.0544; 6.45%; harmful).

The sign of the delivered results favors latent-MSE on the primary outcomes. This directly contradicts a manuscript claim that the observation-aware likelihood outperforms latent-point training in this experiment.

### Patient-specific updating versus source mean

Hidden Dice: -0.0013 (95% CI -0.0030 to 0.0003; -0.18%; inconclusive); Hidden HD95 (px): 0.099 (95% CI 0.044 to 0.157; 1.02%; harmful); Area relative RMSE: 0.0103 (95% CI 0.0073 to 0.0132; 1.74%; harmful).

Patient-specific MAP updating does not outperform the fixed source mean overall. The source mean is essentially invariant to K and strategy, as expected from its implementation; its across-cell area-RMSE range is 0.000758.

![Paired effects](figures/paired_effect_forest.png)

## Secondary ablations and response to observation budget

The full OA-HB-TPM MAP model and its isotropic-prior and no-phase-alignment ablations are practically indistinguishable at the delivered resolution:

- full vs isotropic prior: Hidden Dice: -0.0001 (95% CI -0.0003 to 0.0002; -0.01%; inconclusive); Hidden HD95 (px): 0.001 (95% CI -0.005 to 0.008; 0.01%; inconclusive); Area relative RMSE: 0.0005 (95% CI 0.0001 to 0.0008; 0.08%; harmful).

- full vs no phase alignment: Hidden Dice: -0.0001 (95% CI -0.0004 to 0.0001; -0.02%; inconclusive); Hidden HD95 (px): 0.002 (95% CI -0.004 to 0.008; 0.02%; inconclusive); Area relative RMSE: 0.0005 (95% CI 0.0002 to 0.0007; 0.08%; harmful).

Latent-MSE improves with larger K, whereas OA-HB-TPM MAP is nearly flat and non-monotonic. The detailed response curves and strategy-specific means are in `tables/performance_by_k.csv` and `tables/strategy_interactions.csv`.

## Fold stability

Performance varies materially across folds. For latent-MSE, the held-out-fold range is 0.7243 to 0.7767 for Dice and 0.2548 to 1.0498 for area RMSE. Leave-one-fold-out estimates retain direction for the largest effects but show why single pooled means are insufficient.

![Fold stability](figures/fold_stability.png)

## Calibration and uncertainty

Nominal 95% area coverage is 40.2% for OA-HB-TPM MAP and 60.0% for latent-MSE, both far below 95%. Their mean relative interval widths are 1.289 and 2.966, respectively. Posterior-predictive Brier scores are 0.04973 and 0.06249. Better Brier score does not rescue the severe coverage deficit.

Source mean has no posterior interval outputs, so its coverage and width are correctly reported as unavailable rather than zero.

![Calibration and coverage](figures/calibration_coverage.png)

## Trust-gate diagnostics

The gate largely acts as a detector of nonuniform observation geometry under this package's calibration scheme. Accepted-versus-rejected errors and patient-bootstrap rank correlations are reported in `tables/trust_gate_accepted_vs_rejected.csv` and `tables/trust_gate_correlations.csv`. These analyses do not establish detection of anatomical family shift, scanner shift, or clinical failure.

![Trust-gate behavior](figures/trust_gate_behavior.png)

## Model and training diagnostics

Training histories, selected epochs, phase offsets, K responsiveness, and checkpoint priors were read directly from the frozen run outputs. Across methods, selected best epochs range from 4 to 69. The checkpoint analysis reconstructs tensor-only state dictionaries without executing model code and summarizes prior mean harmonic energy, covariance trace, condition number, and off-diagonal correlation.

For OA-HB-TPM MAP checkpoints, mean prior harmonic-energy fraction is 0.760; the median recorded covariance condition-number summary is 1.12. These are descriptive diagnostics, not evidence that the learned covariance is beneficial: the isotropic-prior ablation is nearly identical in outcome space.

## Oracle-contour upper bound

- Hidden Dice: oracle 0.9375 versus best learned 0.7532 (HB-TPM latent-MSE); improvement-oriented oracle advantage 0.1844.
- Hidden HD95 (px): oracle 2.290 versus best learned 9.406 (HB-TPM latent-MSE); improvement-oriented oracle advantage 7.116.
- Area relative RMSE: oracle 0.0926 versus best learned 0.5646 (HB-TPM latent-MSE); improvement-oriented oracle advantage 0.4720.

The large gap is consistent with image-to-latent estimation being the main bottleneck. Because the oracle consumes manual contours, it is an upper-bound diagnostic and must not be placed in an undifferentiated end-to-end model ranking.

![Oracle gap](figures/oracle_gap.png)

## Data integrity and provenance

The analysis verified the ZIP SHA-256 checksum, 150 run manifests, every recorded run-output hash, 32,340 learned-method rows, 98 unique patients, five mutually exclusive folds, six methods, five K values, three strategies, complete replicate counts, zero duplicate full keys, finite primary metrics, and false hidden-image/hidden-mask leakage flags. Every supplied aggregate value and frozen bootstrap interval was independently reproduced to numerical tolerance.

The bundled experiment-code snapshot matches the current tracked package after line-ending normalization. The recorded run commit `6fbc8c9490ed64612236c5346b62c2f769e2b2a8` is not present in local Git history. traceback retained; completed manifest reports 220 successful and 0 failed observations; therefore `target_only/fold0_k2.log` is retained as a warning about an earlier failed attempt, not evidence that the final run failed.

Exact input and output hashes, environment versions, seed, and bootstrap settings are recorded in `analysis_manifest.json`. Figure-to-table provenance is in `FIGURE_PROVENANCE.csv`.

## Limitations and manuscript implications

- Classical baselines specified by the frozen design are absent. The package cannot support superiority claims against linear interpolation, splines, Gaussian processes, or other conventional comparators.

- Family-shift validation is absent. Trust-gate conclusions are limited to sampling-pattern sensitivity.

- ED/ES timing error, temporal jerk, and several other planned secondary outcomes are absent.

- Raw target image arrays are not included, so inference cannot be rerun independently from this package. This report analyzes the frozen outputs without recomputing predictions.

- The sample contains 98 patients across five folds and exhibits substantial fold heterogeneity. External validity and clinical relevance remain unestablished.

A defensible manuscript can state that latent-MSE HB-TPM was the strongest delivered end-to-end method and that a large oracle gap remains. It should not state that OA-HB-TPM MAP outperforms latent-MSE or source mean, that its nominal intervals are calibrated, that the trust gate detects family shift, or that clinical significance has been shown.

## Recommended next experiments

1. Add the frozen classical baselines and report identical patient-level paired contrasts.

2. Calibrate posterior scale on held-out source/validation patients, then evaluate coverage and Brier scores without reusing the test patients.

3. Isolate the image-to-latent bottleneck with controlled encoder/initializer improvements while preserving the same trajectory decoder and folds.

4. Run a prespecified external or family/vendor-shift evaluation for the trust gate, including error-detection AUROC/AUPRC and coverage conditional on acceptance.

5. Add ED/ES timing, temporal smoothness/jerk, runtime, and clinically motivated effect thresholds before drafting clinical conclusions.

## Machine-readable outputs

All patient identifiers are confined to `tables/canonical_patient_cells.csv`; the narrative and figures contain aggregates only. The claim-to-evidence map is `tables/claim_status.csv`, and missing planned outcomes are enumerated in `tables/missing_deliverables.csv`.
